## Google Drive setting


```python
from google.colab import drive
drive.mount('/content/drive')
```

    Drive already mounted at /content/drive; to attempt to forcibly remount, call drive.mount("/content/drive", force_remount=True).
    


```python
%cd /content/drive/MyDrive/AIncome
```

    /content/drive/MyDrive/AIncome
    


```python
!pwd
```

    /content/drive/MyDrive/AIncome
    

### 作業フォルダ


```python
!mkdir AutoTrade10
```

    mkdir: cannot create directory ‘AutoTrade10’: File exists
    


```python
%cd  AutoTrade10
```

    /content/drive/MyDrive/AIncome/AutoTrade10
    


```python
!pwd
```

    /content/drive/MyDrive/AIncome/AutoTrade10
    

## 必要パッケージのインストール


```python
"""
#!pip install gym[all] -U
!pip install "gym==0.19.0"
!pip install stable-baselines[mpi]
#!pip install tensorflow==1.14.0
!pip install tensorflow-gpu==1.14.0
!pip install pyqt5
!pip install imageio
!pip install gym-anytrading
"""
!pip install "gym==0.19.0"
!pip install stable-baselines[mpi]
!pip uninstall -y tensorflow-gpu
!pip uninstall -y tensorflow
!pip install tensorflow-gpu==1.14.0
!pip install gym-anytrading

!pip install QuantStats
```

    Looking in indexes: https://pypi.org/simple, https://us-python.pkg.dev/colab-wheels/public/simple/
    Requirement already satisfied: gym==0.19.0 in /usr/local/lib/python3.7/dist-packages (0.19.0)
    Requirement already satisfied: numpy>=1.18.0 in /usr/local/lib/python3.7/dist-packages (from gym==0.19.0) (1.21.6)
    Requirement already satisfied: cloudpickle<1.7.0,>=1.2.0 in /usr/local/lib/python3.7/dist-packages (from gym==0.19.0) (1.5.0)
    Looking in indexes: https://pypi.org/simple, https://us-python.pkg.dev/colab-wheels/public/simple/
    Requirement already satisfied: stable-baselines[mpi] in /usr/local/lib/python3.7/dist-packages (2.10.2)
    Requirement already satisfied: pandas in /usr/local/lib/python3.7/dist-packages (from stable-baselines[mpi]) (1.3.5)
    Requirement already satisfied: cloudpickle>=0.5.5 in /usr/local/lib/python3.7/dist-packages (from stable-baselines[mpi]) (1.5.0)
    Requirement already satisfied: scipy in /usr/local/lib/python3.7/dist-packages (from stable-baselines[mpi]) (1.7.3)
    Requirement already satisfied: opencv-python in /usr/local/lib/python3.7/dist-packages (from stable-baselines[mpi]) (4.6.0.66)
    Requirement already satisfied: joblib in /usr/local/lib/python3.7/dist-packages (from stable-baselines[mpi]) (1.1.0)
    Requirement already satisfied: numpy in /usr/local/lib/python3.7/dist-packages (from stable-baselines[mpi]) (1.21.6)
    Requirement already satisfied: gym[atari,classic_control]>=0.11 in /usr/local/lib/python3.7/dist-packages (from stable-baselines[mpi]) (0.19.0)
    Requirement already satisfied: matplotlib in /usr/local/lib/python3.7/dist-packages (from stable-baselines[mpi]) (3.2.2)
    Requirement already satisfied: mpi4py in /usr/local/lib/python3.7/dist-packages (from stable-baselines[mpi]) (3.1.3)
    Requirement already satisfied: atari-py==0.2.6 in /usr/local/lib/python3.7/dist-packages (from gym[atari,classic_control]>=0.11->stable-baselines[mpi]) (0.2.6)
    Requirement already satisfied: pyglet>=1.4.0 in /usr/local/lib/python3.7/dist-packages (from gym[atari,classic_control]>=0.11->stable-baselines[mpi]) (1.5.26)
    Requirement already satisfied: six in /usr/local/lib/python3.7/dist-packages (from atari-py==0.2.6->gym[atari,classic_control]>=0.11->stable-baselines[mpi]) (1.15.0)
    Requirement already satisfied: cycler>=0.10 in /usr/local/lib/python3.7/dist-packages (from matplotlib->stable-baselines[mpi]) (0.11.0)
    Requirement already satisfied: pyparsing!=2.0.4,!=2.1.2,!=2.1.6,>=2.0.1 in /usr/local/lib/python3.7/dist-packages (from matplotlib->stable-baselines[mpi]) (3.0.9)
    Requirement already satisfied: kiwisolver>=1.0.1 in /usr/local/lib/python3.7/dist-packages (from matplotlib->stable-baselines[mpi]) (1.4.4)
    Requirement already satisfied: python-dateutil>=2.1 in /usr/local/lib/python3.7/dist-packages (from matplotlib->stable-baselines[mpi]) (2.8.2)
    Requirement already satisfied: typing-extensions in /usr/local/lib/python3.7/dist-packages (from kiwisolver>=1.0.1->matplotlib->stable-baselines[mpi]) (4.1.1)
    Requirement already satisfied: pytz>=2017.3 in /usr/local/lib/python3.7/dist-packages (from pandas->stable-baselines[mpi]) (2022.2.1)
    Found existing installation: tensorflow-gpu 1.14.0
    Uninstalling tensorflow-gpu-1.14.0:
      Successfully uninstalled tensorflow-gpu-1.14.0
    [33mWARNING: Skipping tensorflow as it is not installed.[0m
    Looking in indexes: https://pypi.org/simple, https://us-python.pkg.dev/colab-wheels/public/simple/
    Collecting tensorflow-gpu==1.14.0
      Using cached tensorflow_gpu-1.14.0-cp37-cp37m-manylinux1_x86_64.whl (377.1 MB)
    Requirement already satisfied: keras-applications>=1.0.6 in /usr/local/lib/python3.7/dist-packages (from tensorflow-gpu==1.14.0) (1.0.8)
    Requirement already satisfied: six>=1.10.0 in /usr/local/lib/python3.7/dist-packages (from tensorflow-gpu==1.14.0) (1.15.0)
    Requirement already satisfied: numpy<2.0,>=1.14.5 in /usr/local/lib/python3.7/dist-packages (from tensorflow-gpu==1.14.0) (1.21.6)
    Requirement already satisfied: keras-preprocessing>=1.0.5 in /usr/local/lib/python3.7/dist-packages (from tensorflow-gpu==1.14.0) (1.1.2)
    Requirement already satisfied: grpcio>=1.8.6 in /usr/local/lib/python3.7/dist-packages (from tensorflow-gpu==1.14.0) (1.47.0)
    Requirement already satisfied: wheel>=0.26 in /usr/local/lib/python3.7/dist-packages (from tensorflow-gpu==1.14.0) (0.37.1)
    Requirement already satisfied: tensorboard<1.15.0,>=1.14.0 in /usr/local/lib/python3.7/dist-packages (from tensorflow-gpu==1.14.0) (1.14.0)
    Requirement already satisfied: absl-py>=0.7.0 in /usr/local/lib/python3.7/dist-packages (from tensorflow-gpu==1.14.0) (1.2.0)
    Requirement already satisfied: gast>=0.2.0 in /usr/local/lib/python3.7/dist-packages (from tensorflow-gpu==1.14.0) (0.5.3)
    Requirement already satisfied: wrapt>=1.11.1 in /usr/local/lib/python3.7/dist-packages (from tensorflow-gpu==1.14.0) (1.14.1)
    Requirement already satisfied: google-pasta>=0.1.6 in /usr/local/lib/python3.7/dist-packages (from tensorflow-gpu==1.14.0) (0.2.0)
    Requirement already satisfied: astor>=0.6.0 in /usr/local/lib/python3.7/dist-packages (from tensorflow-gpu==1.14.0) (0.8.1)
    Requirement already satisfied: tensorflow-estimator<1.15.0rc0,>=1.14.0rc0 in /usr/local/lib/python3.7/dist-packages (from tensorflow-gpu==1.14.0) (1.14.0)
    Requirement already satisfied: termcolor>=1.1.0 in /usr/local/lib/python3.7/dist-packages (from tensorflow-gpu==1.14.0) (1.1.0)
    Requirement already satisfied: protobuf>=3.6.1 in /usr/local/lib/python3.7/dist-packages (from tensorflow-gpu==1.14.0) (3.17.3)
    Requirement already satisfied: h5py in /usr/local/lib/python3.7/dist-packages (from keras-applications>=1.0.6->tensorflow-gpu==1.14.0) (3.1.0)
    Requirement already satisfied: setuptools>=41.0.0 in /usr/local/lib/python3.7/dist-packages (from tensorboard<1.15.0,>=1.14.0->tensorflow-gpu==1.14.0) (57.4.0)
    Requirement already satisfied: werkzeug>=0.11.15 in /usr/local/lib/python3.7/dist-packages (from tensorboard<1.15.0,>=1.14.0->tensorflow-gpu==1.14.0) (1.0.1)
    Requirement already satisfied: markdown>=2.6.8 in /usr/local/lib/python3.7/dist-packages (from tensorboard<1.15.0,>=1.14.0->tensorflow-gpu==1.14.0) (3.4.1)
    Requirement already satisfied: importlib-metadata>=4.4 in /usr/local/lib/python3.7/dist-packages (from markdown>=2.6.8->tensorboard<1.15.0,>=1.14.0->tensorflow-gpu==1.14.0) (4.12.0)
    Requirement already satisfied: zipp>=0.5 in /usr/local/lib/python3.7/dist-packages (from importlib-metadata>=4.4->markdown>=2.6.8->tensorboard<1.15.0,>=1.14.0->tensorflow-gpu==1.14.0) (3.8.1)
    Requirement already satisfied: typing-extensions>=3.6.4 in /usr/local/lib/python3.7/dist-packages (from importlib-metadata>=4.4->markdown>=2.6.8->tensorboard<1.15.0,>=1.14.0->tensorflow-gpu==1.14.0) (4.1.1)
    Requirement already satisfied: cached-property in /usr/local/lib/python3.7/dist-packages (from h5py->keras-applications>=1.0.6->tensorflow-gpu==1.14.0) (1.5.2)
    Installing collected packages: tensorflow-gpu
    Successfully installed tensorflow-gpu-1.14.0
    



    Looking in indexes: https://pypi.org/simple, https://us-python.pkg.dev/colab-wheels/public/simple/
    Requirement already satisfied: gym-anytrading in /usr/local/lib/python3.7/dist-packages (1.3.1)
    Requirement already satisfied: gym>=0.12.5 in /usr/local/lib/python3.7/dist-packages (from gym-anytrading) (0.19.0)
    Requirement already satisfied: matplotlib>=3.1.1 in /usr/local/lib/python3.7/dist-packages (from gym-anytrading) (3.2.2)
    Requirement already satisfied: pandas>=0.24.2 in /usr/local/lib/python3.7/dist-packages (from gym-anytrading) (1.3.5)
    Requirement already satisfied: numpy>=1.16.4 in /usr/local/lib/python3.7/dist-packages (from gym-anytrading) (1.21.6)
    Requirement already satisfied: cloudpickle<1.7.0,>=1.2.0 in /usr/local/lib/python3.7/dist-packages (from gym>=0.12.5->gym-anytrading) (1.5.0)
    Requirement already satisfied: pyparsing!=2.0.4,!=2.1.2,!=2.1.6,>=2.0.1 in /usr/local/lib/python3.7/dist-packages (from matplotlib>=3.1.1->gym-anytrading) (3.0.9)
    Requirement already satisfied: python-dateutil>=2.1 in /usr/local/lib/python3.7/dist-packages (from matplotlib>=3.1.1->gym-anytrading) (2.8.2)
    Requirement already satisfied: kiwisolver>=1.0.1 in /usr/local/lib/python3.7/dist-packages (from matplotlib>=3.1.1->gym-anytrading) (1.4.4)
    Requirement already satisfied: cycler>=0.10 in /usr/local/lib/python3.7/dist-packages (from matplotlib>=3.1.1->gym-anytrading) (0.11.0)
    Requirement already satisfied: typing-extensions in /usr/local/lib/python3.7/dist-packages (from kiwisolver>=1.0.1->matplotlib>=3.1.1->gym-anytrading) (4.1.1)
    Requirement already satisfied: pytz>=2017.3 in /usr/local/lib/python3.7/dist-packages (from pandas>=0.24.2->gym-anytrading) (2022.2.1)
    Requirement already satisfied: six>=1.5 in /usr/local/lib/python3.7/dist-packages (from python-dateutil>=2.1->matplotlib>=3.1.1->gym-anytrading) (1.15.0)
    Looking in indexes: https://pypi.org/simple, https://us-python.pkg.dev/colab-wheels/public/simple/
    Requirement already satisfied: QuantStats in /usr/local/lib/python3.7/dist-packages (0.0.59)
    Requirement already satisfied: pandas>=0.24.0 in /usr/local/lib/python3.7/dist-packages (from QuantStats) (1.3.5)
    Requirement already satisfied: seaborn>=0.9.0 in /usr/local/lib/python3.7/dist-packages (from QuantStats) (0.11.2)
    Requirement already satisfied: matplotlib>=3.0.0 in /usr/local/lib/python3.7/dist-packages (from QuantStats) (3.2.2)
    Requirement already satisfied: yfinance>=0.1.70 in /usr/local/lib/python3.7/dist-packages (from QuantStats) (0.1.74)
    Requirement already satisfied: scipy>=1.2.0 in /usr/local/lib/python3.7/dist-packages (from QuantStats) (1.7.3)
    Requirement already satisfied: numpy>=1.16.5 in /usr/local/lib/python3.7/dist-packages (from QuantStats) (1.21.6)
    Requirement already satisfied: tabulate>=0.8.0 in /usr/local/lib/python3.7/dist-packages (from QuantStats) (0.8.10)
    Requirement already satisfied: python-dateutil>=2.0 in /usr/local/lib/python3.7/dist-packages (from QuantStats) (2.8.2)
    Requirement already satisfied: cycler>=0.10 in /usr/local/lib/python3.7/dist-packages (from matplotlib>=3.0.0->QuantStats) (0.11.0)
    Requirement already satisfied: pyparsing!=2.0.4,!=2.1.2,!=2.1.6,>=2.0.1 in /usr/local/lib/python3.7/dist-packages (from matplotlib>=3.0.0->QuantStats) (3.0.9)
    Requirement already satisfied: kiwisolver>=1.0.1 in /usr/local/lib/python3.7/dist-packages (from matplotlib>=3.0.0->QuantStats) (1.4.4)
    Requirement already satisfied: typing-extensions in /usr/local/lib/python3.7/dist-packages (from kiwisolver>=1.0.1->matplotlib>=3.0.0->QuantStats) (4.1.1)
    Requirement already satisfied: pytz>=2017.3 in /usr/local/lib/python3.7/dist-packages (from pandas>=0.24.0->QuantStats) (2022.2.1)
    Requirement already satisfied: six>=1.5 in /usr/local/lib/python3.7/dist-packages (from python-dateutil>=2.0->QuantStats) (1.15.0)
    Requirement already satisfied: multitasking>=0.0.7 in /usr/local/lib/python3.7/dist-packages (from yfinance>=0.1.70->QuantStats) (0.0.11)
    Requirement already satisfied: lxml>=4.5.1 in /usr/local/lib/python3.7/dist-packages (from yfinance>=0.1.70->QuantStats) (4.9.1)
    Requirement already satisfied: requests>=2.26 in /usr/local/lib/python3.7/dist-packages (from yfinance>=0.1.70->QuantStats) (2.28.1)
    Requirement already satisfied: certifi>=2017.4.17 in /usr/local/lib/python3.7/dist-packages (from requests>=2.26->yfinance>=0.1.70->QuantStats) (2022.6.15)
    Requirement already satisfied: idna<4,>=2.5 in /usr/local/lib/python3.7/dist-packages (from requests>=2.26->yfinance>=0.1.70->QuantStats) (2.10)
    Requirement already satisfied: urllib3<1.27,>=1.21.1 in /usr/local/lib/python3.7/dist-packages (from requests>=2.26->yfinance>=0.1.70->QuantStats) (1.24.3)
    Requirement already satisfied: charset-normalizer<3,>=2 in /usr/local/lib/python3.7/dist-packages (from requests>=2.26->yfinance>=0.1.70->QuantStats) (2.1.0)
    


```python
!pip uninstall tensorboard-plugin-wit --yes
```

    [33mWARNING: Skipping tensorboard-plugin-wit as it is not installed.[0m
    

## インポート



```python
"""

import gym_anytrading

from gym_anytrading.envs import TradingEnv, ForexEnv, StocksEnv, Actions, Positions
from gym_anytrading.datasets import FOREX_EURUSD_1H_ASK, STOCKS_GOOGL
from stable_baselines.common.vec_env import DummyVecEnv
from stable_baselines import PPO2
from stable_baselines import ACKTR
from stable_baselines.bench import Monitor
from stable_baselines.common import set_global_seeds
"""
import os
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import gym

import gym_anytrading
from gym_anytrading.envs import TradingEnv, ForexEnv, StocksEnv, Actions, Positions
from gym_anytrading.datasets import FOREX_EURUSD_1H_ASK, STOCKS_GOOGL

from stable_baselines.bench import Monitor

from stable_baselines.common.vec_env import DummyVecEnv
from stable_baselines.common.policies import MlpPolicy
from stable_baselines.common import make_vec_env
from stable_baselines import PPO2
from stable_baselines import ACKTR
from stable_baselines import A2C

import quantstats as qs
```

## 設定


```python

# ログフォルダの生成
log_dir = './logs/'
os.makedirs(log_dir, exist_ok=True)


# train data
idx1 = 100
idx2 = 5000

# test data
idx3 = 6000

window_size = 100

trade_fee = 0

```

## Read datasets

ビットコインのデータを読み込んでいきます．


```python
df_dataset = pd.read_csv('./datasets/btc_1D.csv', header=None)
```

列名を表記します．


```python
df_dataset.columns = ["Time", "Open", "High", "Low", "Close", "Vol"]
```

                   Open     High      Low    Close          Vol
    Time                                                       
    2015-06-26    29020    32000    29020    32000     0.033000
    2015-06-27    32000    31700    31700    31700     0.001000
    2015-06-28    31700    31704    30550    31000     2.739000
    2015-06-29    31000    31220    30870    30870     1.280000
    2015-06-30    30870    31550    30900    31550     0.990000
    ...             ...      ...      ...      ...          ...
    2022-08-22  2897228  2982883  2884460  2947952  1417.869557
    2022-08-23  2948139  2964999  2859350  2945000  1901.812426
    2022-08-24  2945000  2970000  2870201  2943127  2145.486097
    2022-08-25  2943835  2998000  2896440  2931406  1692.627332
    2022-08-26  2931406  2978566  2920001  2947374  1318.078997
    
    [2618 rows x 5 columns]
    

`index`をdatetime型の時間にします．


```python
df_dataset["Time"] = pd.to_datetime(df_dataset["Time"])
df_dataset = df_dataset.set_index("Time")
print(df_dataset)
```

## 環境の生成


```python

def my_process_data(env):
    start = env.frame_bound[0] - env.window_size
    end = env.frame_bound[1]
    prices = env.df.loc[:, 'Low'].to_numpy()[start:end]
    signal_features = env.df.loc[:, ['Close', 'Open', 'High', 'Low', 'Vol']].to_numpy()[start:end]
    return prices, signal_features

class MyBTCEnv(ForexEnv):
    _process_data = my_process_data

env_marker2 = lambda:  MyBTCEnv(df=df_dataset, window_size=window_size, frame_bound=(idx1, idx2))
env_marker2.trade_fee = trade_fee

env = DummyVecEnv([env_marker2 for _ in range(1)])

#env = Monitor(env, log_dir, allow_early_resets=True)
```

## Train trade


```python
policy_kwargs = dict(net_arch=[64, 'lstm', dict(vf=[128, 128, 128], pi=[64, 64])])
model = PPO2('MlpLstmPolicy', env, verbose=1, policy_kwargs=policy_kwargs, nminibatches=1, tensorboard_log=log_dir)
model.learn(total_timesteps=100000)
```

    WARNING:tensorflow:From /usr/local/lib/python3.7/dist-packages/stable_baselines/common/tf_util.py:191: The name tf.ConfigProto is deprecated. Please use tf.compat.v1.ConfigProto instead.
    
    WARNING:tensorflow:From /usr/local/lib/python3.7/dist-packages/stable_baselines/common/tf_util.py:200: The name tf.Session is deprecated. Please use tf.compat.v1.Session instead.
    
    WARNING:tensorflow:From /usr/local/lib/python3.7/dist-packages/stable_baselines/common/policies.py:116: The name tf.variable_scope is deprecated. Please use tf.compat.v1.variable_scope instead.
    
    WARNING:tensorflow:From /usr/local/lib/python3.7/dist-packages/stable_baselines/common/input.py:25: The name tf.placeholder is deprecated. Please use tf.compat.v1.placeholder instead.
    
    WARNING:tensorflow:From /usr/local/lib/python3.7/dist-packages/stable_baselines/common/policies.py:442: flatten (from tensorflow.python.layers.core) is deprecated and will be removed in a future version.
    Instructions for updating:
    Use keras.layers.flatten instead.
    WARNING:tensorflow:Entity <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f33d8cbdad0>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f33d8cbdad0>>: AttributeError: module 'gast' has no attribute 'Index'
    WARNING:tensorflow:From /usr/local/lib/python3.7/dist-packages/stable_baselines/common/tf_layers.py:123: The name tf.get_variable is deprecated. Please use tf.compat.v1.get_variable instead.
    
    

    WARNING: Entity <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f33d8cbdad0>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f33d8cbdad0>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING:tensorflow:Entity <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f33d8b95d90>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f33d8b95d90>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING: Entity <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f33d8b95d90>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f33d8b95d90>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING:tensorflow:From /usr/local/lib/python3.7/dist-packages/stable_baselines/ppo2/ppo2.py:190: The name tf.summary.scalar is deprecated. Please use tf.compat.v1.summary.scalar instead.
    
    WARNING:tensorflow:From /usr/local/lib/python3.7/dist-packages/tensorflow/python/ops/math_grad.py:1250: add_dispatch_support.<locals>.wrapper (from tensorflow.python.ops.array_ops) is deprecated and will be removed in a future version.
    Instructions for updating:
    Use tf.where in 2.0, which has the same broadcast rule as np.where
    WARNING:tensorflow:From /usr/local/lib/python3.7/dist-packages/stable_baselines/ppo2/ppo2.py:206: The name tf.train.AdamOptimizer is deprecated. Please use tf.compat.v1.train.AdamOptimizer instead.
    
    WARNING:tensorflow:From /usr/local/lib/python3.7/dist-packages/stable_baselines/ppo2/ppo2.py:242: The name tf.summary.merge_all is deprecated. Please use tf.compat.v1.summary.merge_all instead.
    
    WARNING:tensorflow:From /usr/local/lib/python3.7/dist-packages/stable_baselines/common/base_class.py:1169: The name tf.summary.FileWriter is deprecated. Please use tf.compat.v1.summary.FileWriter instead.
    
    

    -------------------------------------------
    | approxkl           | 0.0009794978       |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 24                 |
    | n_updates          | 1                  |
    | policy_entropy     | 0.69172597         |
    | policy_loss        | -0.0019599954      |
    | serial_timesteps   | 128                |
    | time_elapsed       | 3.89e-05           |
    | total_timesteps    | 128                |
    | value_loss         | 1885447200000000.0 |
    -------------------------------------------
    ------------------------------------------
    | approxkl           | 4.470234e-05      |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 204               |
    | n_updates          | 2                 |
    | policy_entropy     | 0.6887148         |
    | policy_loss        | -0.0010168452     |
    | serial_timesteps   | 256               |
    | time_elapsed       | 5.18              |
    | total_timesteps    | 256               |
    | value_loss         | 439194970000000.0 |
    ------------------------------------------
    -------------------------------------------
    | approxkl           | 0.00014683449      |
    | clipfrac           | 0.0                |
    | explained_variance | 1.19e-07           |
    | fps                | 229                |
    | n_updates          | 3                  |
    | policy_entropy     | 0.69052255         |
    | policy_loss        | 0.001707931        |
    | serial_timesteps   | 384                |
    | time_elapsed       | 5.81               |
    | total_timesteps    | 384                |
    | value_loss         | 1275332400000000.0 |
    -------------------------------------------
    -------------------------------------------
    | approxkl           | 0.0001143679       |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 233                |
    | n_updates          | 4                  |
    | policy_entropy     | 0.6927503          |
    | policy_loss        | -0.0023493522      |
    | serial_timesteps   | 512                |
    | time_elapsed       | 6.37               |
    | total_timesteps    | 512                |
    | value_loss         | 2109993700000000.0 |
    -------------------------------------------
    ---------------------------------------
    | approxkl           | 8.09652e-06    |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 220            |
    | n_updates          | 5              |
    | policy_entropy     | 0.6928154      |
    | policy_loss        | -0.00033124955 |
    | serial_timesteps   | 640            |
    | time_elapsed       | 6.92           |
    | total_timesteps    | 640            |
    | value_loss         | 2.1683142e+17  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 2.5543313e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 237           |
    | n_updates          | 6             |
    | policy_entropy     | 0.6926755     |
    | policy_loss        | 5.3175725e-05 |
    | serial_timesteps   | 768           |
    | time_elapsed       | 7.51          |
    | total_timesteps    | 768           |
    | value_loss         | 1.3309834e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 6.2938394e-05 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 240           |
    | n_updates          | 7             |
    | policy_entropy     | 0.69228435    |
    | policy_loss        | -2.435071e-05 |
    | serial_timesteps   | 896           |
    | time_elapsed       | 8.06          |
    | total_timesteps    | 896           |
    | value_loss         | 6.711868e+18  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 7.454681e-06  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 234           |
    | n_updates          | 8             |
    | policy_entropy     | 0.6927333     |
    | policy_loss        | 0.00016225688 |
    | serial_timesteps   | 1024          |
    | time_elapsed       | 8.59          |
    | total_timesteps    | 1024          |
    | value_loss         | 2.3866678e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 5.5263595e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 243           |
    | n_updates          | 9             |
    | policy_entropy     | 0.69283456    |
    | policy_loss        | -7.68773e-05  |
    | serial_timesteps   | 1152          |
    | time_elapsed       | 9.14          |
    | total_timesteps    | 1152          |
    | value_loss         | 1.5284418e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 4.5337096e-05 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 233           |
    | n_updates          | 10            |
    | policy_entropy     | 0.6923804     |
    | policy_loss        | 0.0013209241  |
    | serial_timesteps   | 1280          |
    | time_elapsed       | 9.67          |
    | total_timesteps    | 1280          |
    | value_loss         | 6.5779778e+16 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 9.489531e-06  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 239           |
    | n_updates          | 11            |
    | policy_entropy     | 0.6904463     |
    | policy_loss        | -0.0001833021 |
    | serial_timesteps   | 1408          |
    | time_elapsed       | 10.2          |
    | total_timesteps    | 1408          |
    | value_loss         | 6.94218e+17   |
    --------------------------------------
    --------------------------------------
    | approxkl           | 2.355778e-06  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 234           |
    | n_updates          | 12            |
    | policy_entropy     | 0.69279397    |
    | policy_loss        | 1.2309523e-05 |
    | serial_timesteps   | 1536          |
    | time_elapsed       | 10.8          |
    | total_timesteps    | 1536          |
    | value_loss         | 4.836023e+17  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 2.6448637e-05 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 236           |
    | n_updates          | 13            |
    | policy_entropy     | 0.6928816     |
    | policy_loss        | 5.3943368e-06 |
    | serial_timesteps   | 1664          |
    | time_elapsed       | 11.3          |
    | total_timesteps    | 1664          |
    | value_loss         | 5.3230636e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 7.953118e-06  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 244           |
    | n_updates          | 14            |
    | policy_entropy     | 0.69242924    |
    | policy_loss        | 9.938725e-05  |
    | serial_timesteps   | 1792          |
    | time_elapsed       | 11.8          |
    | total_timesteps    | 1792          |
    | value_loss         | 1.3918166e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 7.594848e-05  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 235           |
    | n_updates          | 15            |
    | policy_entropy     | 0.69292164    |
    | policy_loss        | -0.0011097745 |
    | serial_timesteps   | 1920          |
    | time_elapsed       | 12.4          |
    | total_timesteps    | 1920          |
    | value_loss         | 2.7673966e+18 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 0.00017459838 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 235           |
    | n_updates          | 16            |
    | policy_entropy     | 0.69293284    |
    | policy_loss        | -0.000638122  |
    | serial_timesteps   | 2048          |
    | time_elapsed       | 12.9          |
    | total_timesteps    | 2048          |
    | value_loss         | 2.379016e+19  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 0.00022158009 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 206           |
    | n_updates          | 17            |
    | policy_entropy     | 0.6908173     |
    | policy_loss        | 0.00078770635 |
    | serial_timesteps   | 2176          |
    | time_elapsed       | 13.5          |
    | total_timesteps    | 2176          |
    | value_loss         | 5.954236e+18  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 0.00036785408 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 192           |
    | n_updates          | 18            |
    | policy_entropy     | 0.68378985    |
    | policy_loss        | 0.00033165258 |
    | serial_timesteps   | 2304          |
    | time_elapsed       | 14.1          |
    | total_timesteps    | 2304          |
    | value_loss         | 1.3421081e+19 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 0.00037151805 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 189           |
    | n_updates          | 19            |
    | policy_entropy     | 0.6775688     |
    | policy_loss        | -0.00156772   |
    | serial_timesteps   | 2432          |
    | time_elapsed       | 14.8          |
    | total_timesteps    | 2432          |
    | value_loss         | 5.361624e+18  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 0.00013716426 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 215           |
    | n_updates          | 20            |
    | policy_entropy     | 0.6744592     |
    | policy_loss        | 0.0018620376  |
    | serial_timesteps   | 2560          |
    | time_elapsed       | 15.4          |
    | total_timesteps    | 2560          |
    | value_loss         | 4.4323994e+18 |
    --------------------------------------
    ------------------------------------------
    | approxkl           | 2.0951462e-05     |
    | clipfrac           | 0.0               |
    | explained_variance | 1.19e-07          |
    | fps                | 240               |
    | n_updates          | 21                |
    | policy_entropy     | 0.6688225         |
    | policy_loss        | 0.00028439658     |
    | serial_timesteps   | 2688              |
    | time_elapsed       | 16                |
    | total_timesteps    | 2688              |
    | value_loss         | 559713700000000.0 |
    ------------------------------------------
    -------------------------------------------
    | approxkl           | 1.0769383e-05      |
    | clipfrac           | 0.0                |
    | explained_variance | 5.96e-08           |
    | fps                | 205                |
    | n_updates          | 22                 |
    | policy_entropy     | 0.66346383         |
    | policy_loss        | -0.00013798289     |
    | serial_timesteps   | 2816               |
    | time_elapsed       | 16.6               |
    | total_timesteps    | 2816               |
    | value_loss         | 1972591000000000.0 |
    -------------------------------------------
    --------------------------------------
    | approxkl           | 5.1507825e-05 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 185           |
    | n_updates          | 23            |
    | policy_entropy     | 0.66188025    |
    | policy_loss        | -0.0001550233 |
    | serial_timesteps   | 2944          |
    | time_elapsed       | 17.2          |
    | total_timesteps    | 2944          |
    | value_loss         | 5.4963753e+16 |
    --------------------------------------
    -------------------------------------------
    | approxkl           | 3.2700054e-06      |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 195                |
    | n_updates          | 24                 |
    | policy_entropy     | 0.6642046          |
    | policy_loss        | 0.00011979602      |
    | serial_timesteps   | 3072               |
    | time_elapsed       | 17.9               |
    | total_timesteps    | 3072               |
    | value_loss         | 8246549000000000.0 |
    -------------------------------------------
    --------------------------------------
    | approxkl           | 1.4331162e-05 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 185           |
    | n_updates          | 25            |
    | policy_entropy     | 0.66601145    |
    | policy_loss        | 0.00022305863 |
    | serial_timesteps   | 3200          |
    | time_elapsed       | 18.5          |
    | total_timesteps    | 3200          |
    | value_loss         | 1.809832e+17  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 5.3644435e-05 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 191           |
    | n_updates          | 26            |
    | policy_entropy     | 0.6684458     |
    | policy_loss        | 0.0007487184  |
    | serial_timesteps   | 3328          |
    | time_elapsed       | 19.2          |
    | total_timesteps    | 3328          |
    | value_loss         | 5.246076e+18  |
    --------------------------------------
    -------------------------------------
    | approxkl           | 7.633773e-05 |
    | clipfrac           | 0.0          |
    | explained_variance | 0            |
    | fps                | 228          |
    | n_updates          | 27           |
    | policy_entropy     | 0.67966557   |
    | policy_loss        | 0.0015179028 |
    | serial_timesteps   | 3456         |
    | time_elapsed       | 19.9         |
    | total_timesteps    | 3456         |
    | value_loss         | 9.954202e+17 |
    -------------------------------------
    --------------------------------------
    | approxkl           | 1.9773135e-05 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 224           |
    | n_updates          | 28            |
    | policy_entropy     | 0.67449033    |
    | policy_loss        | 0.0008375682  |
    | serial_timesteps   | 3584          |
    | time_elapsed       | 20.5          |
    | total_timesteps    | 3584          |
    | value_loss         | 2.2248833e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.0580241e-05 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 191           |
    | n_updates          | 29            |
    | policy_entropy     | 0.6775466     |
    | policy_loss        | -3.558467e-05 |
    | serial_timesteps   | 3712          |
    | time_elapsed       | 21            |
    | total_timesteps    | 3712          |
    | value_loss         | 2.1744712e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 7.2796365e-06  |
    | clipfrac           | 0.0            |
    | explained_variance | -1.19e-07      |
    | fps                | 195            |
    | n_updates          | 30             |
    | policy_entropy     | 0.68066716     |
    | policy_loss        | -0.00041901658 |
    | serial_timesteps   | 3840           |
    | time_elapsed       | 21.7           |
    | total_timesteps    | 3840           |
    | value_loss         | 2.0314113e+17  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 9.033829e-06  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 203           |
    | n_updates          | 31            |
    | policy_entropy     | 0.6834127     |
    | policy_loss        | -5.827658e-05 |
    | serial_timesteps   | 3968          |
    | time_elapsed       | 22.4          |
    | total_timesteps    | 3968          |
    | value_loss         | 5.1094436e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 3.507087e-07  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 194           |
    | n_updates          | 32            |
    | policy_entropy     | 0.6759335     |
    | policy_loss        | -9.444775e-06 |
    | serial_timesteps   | 4096          |
    | time_elapsed       | 23            |
    | total_timesteps    | 4096          |
    | value_loss         | 1.2015561e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.8097358e-05 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 195           |
    | n_updates          | 33            |
    | policy_entropy     | 0.67856586    |
    | policy_loss        | 0.00021512073 |
    | serial_timesteps   | 4224          |
    | time_elapsed       | 23.7          |
    | total_timesteps    | 4224          |
    | value_loss         | 1.3140263e+18 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 9.849154e-06  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 203           |
    | n_updates          | 34            |
    | policy_entropy     | 0.68211347    |
    | policy_loss        | 0.00029209442 |
    | serial_timesteps   | 4352          |
    | time_elapsed       | 24.3          |
    | total_timesteps    | 4352          |
    | value_loss         | 1.1355058e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 3.0270246e-06  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 202            |
    | n_updates          | 35             |
    | policy_entropy     | 0.6846961      |
    | policy_loss        | -0.00015051826 |
    | serial_timesteps   | 4480           |
    | time_elapsed       | 25             |
    | total_timesteps    | 4480           |
    | value_loss         | 9.436961e+18   |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 1.6288901e-05 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 206           |
    | n_updates          | 36            |
    | policy_entropy     | 0.68272793    |
    | policy_loss        | -0.0006560823 |
    | serial_timesteps   | 4608          |
    | time_elapsed       | 25.6          |
    | total_timesteps    | 4608          |
    | value_loss         | 2.8798672e+19 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.3232061e-05 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 198           |
    | n_updates          | 37            |
    | policy_entropy     | 0.6801827     |
    | policy_loss        | 0.00023148255 |
    | serial_timesteps   | 4736          |
    | time_elapsed       | 26.2          |
    | total_timesteps    | 4736          |
    | value_loss         | 9.379951e+18  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 4.1658222e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 192           |
    | n_updates          | 38            |
    | policy_entropy     | 0.67662823    |
    | policy_loss        | 9.632413e-05  |
    | serial_timesteps   | 4864          |
    | time_elapsed       | 26.9          |
    | total_timesteps    | 4864          |
    | value_loss         | 1.0596357e+19 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 2.0593623e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 198           |
    | n_updates          | 39            |
    | policy_entropy     | 0.67828       |
    | policy_loss        | 2.537854e-07  |
    | serial_timesteps   | 4992          |
    | time_elapsed       | 27.5          |
    | total_timesteps    | 4992          |
    | value_loss         | 3.6202828e+18 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.6296175e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 240           |
    | n_updates          | 40            |
    | policy_entropy     | 0.67745554    |
    | policy_loss        | 0.00013423071 |
    | serial_timesteps   | 5120          |
    | time_elapsed       | 28.2          |
    | total_timesteps    | 5120          |
    | value_loss         | 1.6529766e+18 |
    --------------------------------------
    ------------------------------------------
    | approxkl           | 6.48716e-06       |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 255               |
    | n_updates          | 41                |
    | policy_entropy     | 0.6769251         |
    | policy_loss        | -0.0003278656     |
    | serial_timesteps   | 5248              |
    | time_elapsed       | 28.7              |
    | total_timesteps    | 5248              |
    | value_loss         | 491400160000000.0 |
    ------------------------------------------
    -------------------------------------------
    | approxkl           | 4.755133e-07       |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 249                |
    | n_updates          | 42                 |
    | policy_entropy     | 0.6755356          |
    | policy_loss        | 6.852404e-05       |
    | serial_timesteps   | 5376               |
    | time_elapsed       | 29.2               |
    | total_timesteps    | 5376               |
    | value_loss         | 3156840400000000.0 |
    -------------------------------------------
    -------------------------------------------
    | approxkl           | 2.5173917e-06      |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 249                |
    | n_updates          | 43                 |
    | policy_entropy     | 0.6761517          |
    | policy_loss        | 2.8747716e-05      |
    | serial_timesteps   | 5504               |
    | time_elapsed       | 29.8               |
    | total_timesteps    | 5504               |
    | value_loss         | 3265328600000000.0 |
    -------------------------------------------
    -------------------------------------------
    | approxkl           | 2.2041631e-06      |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 246                |
    | n_updates          | 44                 |
    | policy_entropy     | 0.67721343         |
    | policy_loss        | -4.5746332e-05     |
    | serial_timesteps   | 5632               |
    | time_elapsed       | 30.3               |
    | total_timesteps    | 5632               |
    | value_loss         | 7955384300000000.0 |
    -------------------------------------------
    --------------------------------------
    | approxkl           | 1.1420185e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 224           |
    | n_updates          | 45            |
    | policy_entropy     | 0.6777001     |
    | policy_loss        | -6.035145e-05 |
    | serial_timesteps   | 5760          |
    | time_elapsed       | 30.8          |
    | total_timesteps    | 5760          |
    | value_loss         | 2.3178875e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.581483e-06  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 198           |
    | n_updates          | 46            |
    | policy_entropy     | 0.6817001     |
    | policy_loss        | 6.369641e-05  |
    | serial_timesteps   | 5888          |
    | time_elapsed       | 31.4          |
    | total_timesteps    | 5888          |
    | value_loss         | 2.0526794e+18 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 5.96678e-06   |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 227           |
    | n_updates          | 47            |
    | policy_entropy     | 0.68174493    |
    | policy_loss        | 0.00013601722 |
    | serial_timesteps   | 6016          |
    | time_elapsed       | 32            |
    | total_timesteps    | 6016          |
    | value_loss         | 6.522316e+17  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 4.9030855e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 251           |
    | n_updates          | 48            |
    | policy_entropy     | 0.6799063     |
    | policy_loss        | -0.0001025307 |
    | serial_timesteps   | 6144          |
    | time_elapsed       | 32.6          |
    | total_timesteps    | 6144          |
    | value_loss         | 1.6953727e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 4.037036e-06   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 198            |
    | n_updates          | 49             |
    | policy_entropy     | 0.68309915     |
    | policy_loss        | -4.0748157e-05 |
    | serial_timesteps   | 6272           |
    | time_elapsed       | 33.1           |
    | total_timesteps    | 6272           |
    | value_loss         | 7.0668825e+16  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 1.2079981e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 195           |
    | n_updates          | 50            |
    | policy_entropy     | 0.6821957     |
    | policy_loss        | 1.4098128e-05 |
    | serial_timesteps   | 6400          |
    | time_elapsed       | 33.7          |
    | total_timesteps    | 6400          |
    | value_loss         | 7.727113e+16  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.8360182e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 192           |
    | n_updates          | 51            |
    | policy_entropy     | 0.6805495     |
    | policy_loss        | 2.9206276e-06 |
    | serial_timesteps   | 6528          |
    | time_elapsed       | 34.4          |
    | total_timesteps    | 6528          |
    | value_loss         | 4.8307308e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 3.5705411e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 194           |
    | n_updates          | 52            |
    | policy_entropy     | 0.68044937    |
    | policy_loss        | 0.00012242468 |
    | serial_timesteps   | 6656          |
    | time_elapsed       | 35.1          |
    | total_timesteps    | 6656          |
    | value_loss         | 4.7397235e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 9.1060963e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 207            |
    | n_updates          | 53             |
    | policy_entropy     | 0.6785755      |
    | policy_loss        | -0.00010794343 |
    | serial_timesteps   | 6784           |
    | time_elapsed       | 35.7           |
    | total_timesteps    | 6784           |
    | value_loss         | 4.3059466e+17  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 1.7008952e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 251           |
    | n_updates          | 54            |
    | policy_entropy     | 0.6804656     |
    | policy_loss        | 0.00032710005 |
    | serial_timesteps   | 6912          |
    | time_elapsed       | 36.4          |
    | total_timesteps    | 6912          |
    | value_loss         | 3.6997793e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.677505e-06  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 252           |
    | n_updates          | 55            |
    | policy_entropy     | 0.6819973     |
    | policy_loss        | 8.3838124e-05 |
    | serial_timesteps   | 7040          |
    | time_elapsed       | 36.9          |
    | total_timesteps    | 7040          |
    | value_loss         | 1.1881227e+19 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 3.2845549e-06  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 245            |
    | n_updates          | 56             |
    | policy_entropy     | 0.6811539      |
    | policy_loss        | -0.00010260497 |
    | serial_timesteps   | 7168           |
    | time_elapsed       | 37.4           |
    | total_timesteps    | 7168           |
    | value_loss         | 1.1428228e+19  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 1.8863602e-05  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 236            |
    | n_updates          | 57             |
    | policy_entropy     | 0.67853516     |
    | policy_loss        | -0.00042115804 |
    | serial_timesteps   | 7296           |
    | time_elapsed       | 37.9           |
    | total_timesteps    | 7296           |
    | value_loss         | 2.0892232e+19  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 2.269098e-05  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 250           |
    | n_updates          | 58            |
    | policy_entropy     | 0.67683387    |
    | policy_loss        | -0.0005771427 |
    | serial_timesteps   | 7424          |
    | time_elapsed       | 38.4          |
    | total_timesteps    | 7424          |
    | value_loss         | 7.5889095e+18 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 3.1092648e-05 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 245           |
    | n_updates          | 59            |
    | policy_entropy     | 0.676145      |
    | policy_loss        | -0.0004765659 |
    | serial_timesteps   | 7552          |
    | time_elapsed       | 39            |
    | total_timesteps    | 7552          |
    | value_loss         | 1.011247e+19  |
    --------------------------------------
    -------------------------------------------
    | approxkl           | 7.508085e-06       |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 243                |
    | n_updates          | 60                 |
    | policy_entropy     | 0.6728034          |
    | policy_loss        | 0.00019230263      |
    | serial_timesteps   | 7680               |
    | time_elapsed       | 39.5               |
    | total_timesteps    | 7680               |
    | value_loss         | 1827505000000000.0 |
    -------------------------------------------
    ------------------------------------------
    | approxkl           | 2.3085836e-06     |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 244               |
    | n_updates          | 61                |
    | policy_entropy     | 0.6737013         |
    | policy_loss        | 9.7865704e-05     |
    | serial_timesteps   | 7808              |
    | time_elapsed       | 40                |
    | total_timesteps    | 7808              |
    | value_loss         | 333222150000000.0 |
    ------------------------------------------
    -------------------------------------------
    | approxkl           | 1.0581775e-06      |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 245                |
    | n_updates          | 62                 |
    | policy_entropy     | 0.67039806         |
    | policy_loss        | 7.357239e-05       |
    | serial_timesteps   | 7936               |
    | time_elapsed       | 40.5               |
    | total_timesteps    | 7936               |
    | value_loss         | 2555094600000000.0 |
    -------------------------------------------
    -------------------------------------------
    | approxkl           | 3.5302378e-07      |
    | clipfrac           | 0.0                |
    | explained_variance | 5.96e-08           |
    | fps                | 227                |
    | n_updates          | 63                 |
    | policy_entropy     | 0.67063636         |
    | policy_loss        | -2.848613e-05      |
    | serial_timesteps   | 8064               |
    | time_elapsed       | 41.1               |
    | total_timesteps    | 8064               |
    | value_loss         | 2053013400000000.0 |
    -------------------------------------------
    --------------------------------------
    | approxkl           | 2.5828217e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 199           |
    | n_updates          | 64            |
    | policy_entropy     | 0.6717136     |
    | policy_loss        | 6.3397456e-06 |
    | serial_timesteps   | 8192          |
    | time_elapsed       | 41.6          |
    | total_timesteps    | 8192          |
    | value_loss         | 9.392607e+16  |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 7.303724e-08   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 196            |
    | n_updates          | 65             |
    | policy_entropy     | 0.6722443      |
    | policy_loss        | -2.3661181e-05 |
    | serial_timesteps   | 8320           |
    | time_elapsed       | 42.3           |
    | total_timesteps    | 8320           |
    | value_loss         | 2.4997667e+17  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 2.3279556e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 214           |
    | n_updates          | 66            |
    | policy_entropy     | 0.67607105    |
    | policy_loss        | 3.732601e-05  |
    | serial_timesteps   | 8448          |
    | time_elapsed       | 42.9          |
    | total_timesteps    | 8448          |
    | value_loss         | 6.4635533e+18 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.5640243e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 249           |
    | n_updates          | 67            |
    | policy_entropy     | 0.6716782     |
    | policy_loss        | 6.7236135e-05 |
    | serial_timesteps   | 8576          |
    | time_elapsed       | 43.5          |
    | total_timesteps    | 8576          |
    | value_loss         | 1.4021117e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 8.613077e-06  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 229           |
    | n_updates          | 68            |
    | policy_entropy     | 0.66973734    |
    | policy_loss        | 9.147031e-05  |
    | serial_timesteps   | 8704          |
    | time_elapsed       | 44            |
    | total_timesteps    | 8704          |
    | value_loss         | 2.0694154e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 2.8183971e-05 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 201           |
    | n_updates          | 69            |
    | policy_entropy     | 0.66791856    |
    | policy_loss        | -6.39963e-05  |
    | serial_timesteps   | 8832          |
    | time_elapsed       | 44.6          |
    | total_timesteps    | 8832          |
    | value_loss         | 8.16474e+16   |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.177051e-05   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 226            |
    | n_updates          | 70             |
    | policy_entropy     | 0.6664477      |
    | policy_loss        | -0.00034264743 |
    | serial_timesteps   | 8960           |
    | time_elapsed       | 45.2           |
    | total_timesteps    | 8960           |
    | value_loss         | 4.853706e+17   |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 1.9107367e-05 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 243           |
    | n_updates          | 71            |
    | policy_entropy     | 0.65640664    |
    | policy_loss        | -0.0001381181 |
    | serial_timesteps   | 9088          |
    | time_elapsed       | 45.8          |
    | total_timesteps    | 9088          |
    | value_loss         | 2.8027544e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 2.5540536e-05  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 199            |
    | n_updates          | 72             |
    | policy_entropy     | 0.65513736     |
    | policy_loss        | -0.00034299365 |
    | serial_timesteps   | 9216           |
    | time_elapsed       | 46.4           |
    | total_timesteps    | 9216           |
    | value_loss         | 1.2688078e+18  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 1.3069661e-05  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 201            |
    | n_updates          | 73             |
    | policy_entropy     | 0.6504846      |
    | policy_loss        | -0.00036201975 |
    | serial_timesteps   | 9344           |
    | time_elapsed       | 47             |
    | total_timesteps    | 9344           |
    | value_loss         | 2.0083563e+17  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 6.3249416e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 193            |
    | n_updates          | 74             |
    | policy_entropy     | 0.65299        |
    | policy_loss        | -0.00010254886 |
    | serial_timesteps   | 9472           |
    | time_elapsed       | 47.6           |
    | total_timesteps    | 9472           |
    | value_loss         | 5.765293e+17   |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 1.5216494e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 154           |
    | n_updates          | 75            |
    | policy_entropy     | 0.66123426    |
    | policy_loss        | -7.531e-05    |
    | serial_timesteps   | 9600          |
    | time_elapsed       | 48.3          |
    | total_timesteps    | 9600          |
    | value_loss         | 1.4035409e+19 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.4253419e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 148           |
    | n_updates          | 76            |
    | policy_entropy     | 0.65198696    |
    | policy_loss        | 0.00016509532 |
    | serial_timesteps   | 9728          |
    | time_elapsed       | 49.1          |
    | total_timesteps    | 9728          |
    | value_loss         | 2.147761e+19  |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.4909683e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 176            |
    | n_updates          | 77             |
    | policy_entropy     | 0.65148395     |
    | policy_loss        | -2.0776177e-05 |
    | serial_timesteps   | 9856           |
    | time_elapsed       | 50             |
    | total_timesteps    | 9856           |
    | value_loss         | 1.8820088e+19  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 1.9114036e-06  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 255            |
    | n_updates          | 78             |
    | policy_entropy     | 0.6485928      |
    | policy_loss        | -9.5768366e-05 |
    | serial_timesteps   | 9984           |
    | time_elapsed       | 50.7           |
    | total_timesteps    | 9984           |
    | value_loss         | 9.35079e+18    |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 2.0860914e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 234           |
    | n_updates          | 79            |
    | policy_entropy     | 0.651192      |
    | policy_loss        | 0.0002360805  |
    | serial_timesteps   | 10112         |
    | time_elapsed       | 51.2          |
    | total_timesteps    | 10112         |
    | value_loss         | 3.5994968e+18 |
    --------------------------------------
    ------------------------------------------
    | approxkl           | 6.3113966e-08     |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 191               |
    | n_updates          | 80                |
    | policy_entropy     | 0.65445125        |
    | policy_loss        | 8.903211e-06      |
    | serial_timesteps   | 10240             |
    | time_elapsed       | 51.8              |
    | total_timesteps    | 10240             |
    | value_loss         | 423365460000000.0 |
    ------------------------------------------
    ------------------------------------------
    | approxkl           | 5.79553e-07       |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 200               |
    | n_updates          | 81                |
    | policy_entropy     | 0.6543462         |
    | policy_loss        | 5.3912518e-05     |
    | serial_timesteps   | 10368             |
    | time_elapsed       | 52.5              |
    | total_timesteps    | 10368             |
    | value_loss         | 828695700000000.0 |
    ------------------------------------------
    

    /usr/local/lib/python3.7/dist-packages/gym_anytrading/envs/forex_env.py:65: RuntimeWarning: divide by zero encountered in double_scalars
      self._total_profit = quantity / current_price
    

    [1;30;43mストリーミング出力は最後の 5000 行に切り捨てられました。[0m
    | n_updates          | 397                |
    | policy_entropy     | 0.61850274         |
    | policy_loss        | -1.80793e-05       |
    | serial_timesteps   | 50816              |
    | time_elapsed       | 244                |
    | total_timesteps    | 50816              |
    | value_loss         | 1018367150000000.0 |
    -------------------------------------------
    ---------------------------------------
    | approxkl           | 1.31477975e-08 |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 183            |
    | n_updates          | 398            |
    | policy_entropy     | 0.6195042      |
    | policy_loss        | 9.9404715e-06  |
    | serial_timesteps   | 50944          |
    | time_elapsed       | 244            |
    | total_timesteps    | 50944          |
    | value_loss         | 1.4557947e+16  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 1.45079e-07   |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 237           |
    | n_updates          | 399           |
    | policy_entropy     | 0.619116      |
    | policy_loss        | 2.6387395e-05 |
    | serial_timesteps   | 51072         |
    | time_elapsed       | 245           |
    | total_timesteps    | 51072         |
    | value_loss         | 2.939318e+17  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 7.930754e-07  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 239           |
    | n_updates          | 400           |
    | policy_entropy     | 0.62221193    |
    | policy_loss        | 8.162402e-05  |
    | serial_timesteps   | 51200         |
    | time_elapsed       | 246           |
    | total_timesteps    | 51200         |
    | value_loss         | 1.1730133e+19 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.8530798e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 194           |
    | n_updates          | 401           |
    | policy_entropy     | 0.627322      |
    | policy_loss        | 1.0003336e-05 |
    | serial_timesteps   | 51328         |
    | time_elapsed       | 246           |
    | total_timesteps    | 51328         |
    | value_loss         | 9.0560684e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.3037446e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 216           |
    | n_updates          | 402           |
    | policy_entropy     | 0.62627244    |
    | policy_loss        | 7.292209e-05  |
    | serial_timesteps   | 51456         |
    | time_elapsed       | 247           |
    | total_timesteps    | 51456         |
    | value_loss         | 9.064999e+16  |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 9.837318e-07   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 239            |
    | n_updates          | 403            |
    | policy_entropy     | 0.629148       |
    | policy_loss        | -4.9549155e-05 |
    | serial_timesteps   | 51584          |
    | time_elapsed       | 247            |
    | total_timesteps    | 51584          |
    | value_loss         | 3.825557e+16   |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 1.4846663e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 239           |
    | n_updates          | 404           |
    | policy_entropy     | 0.6280184     |
    | policy_loss        | 0.00018456765 |
    | serial_timesteps   | 51712         |
    | time_elapsed       | 248           |
    | total_timesteps    | 51712         |
    | value_loss         | 4.2436136e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.558715e-06  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 239           |
    | n_updates          | 405           |
    | policy_entropy     | 0.6274194     |
    | policy_loss        | 6.956444e-05  |
    | serial_timesteps   | 51840         |
    | time_elapsed       | 249           |
    | total_timesteps    | 51840         |
    | value_loss         | 5.4509715e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.0382514e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 200           |
    | n_updates          | 406           |
    | policy_entropy     | 0.63069797    |
    | policy_loss        | 0.00016795006 |
    | serial_timesteps   | 51968         |
    | time_elapsed       | 249           |
    | total_timesteps    | 51968         |
    | value_loss         | 4.6803124e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 7.219263e-07  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 194           |
    | n_updates          | 407           |
    | policy_entropy     | 0.629081      |
    | policy_loss        | -7.333758e-05 |
    | serial_timesteps   | 52096         |
    | time_elapsed       | 250           |
    | total_timesteps    | 52096         |
    | value_loss         | 3.8196914e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.749515e-06  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 195           |
    | n_updates          | 408           |
    | policy_entropy     | 0.63421005    |
    | policy_loss        | 8.41124e-06   |
    | serial_timesteps   | 52224         |
    | time_elapsed       | 250           |
    | total_timesteps    | 52224         |
    | value_loss         | 1.8777952e+18 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 7.319818e-07  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 190           |
    | n_updates          | 409           |
    | policy_entropy     | 0.62931573    |
    | policy_loss        | 2.2063963e-05 |
    | serial_timesteps   | 52352         |
    | time_elapsed       | 251           |
    | total_timesteps    | 52352         |
    | value_loss         | 2.2133336e+19 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.6839698e-06  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 189            |
    | n_updates          | 410            |
    | policy_entropy     | 0.6342707      |
    | policy_loss        | -3.9739534e-06 |
    | serial_timesteps   | 52480          |
    | time_elapsed       | 252            |
    | total_timesteps    | 52480          |
    | value_loss         | 1.7239522e+19  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 2.1774126e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 230           |
    | n_updates          | 411           |
    | policy_entropy     | 0.6337663     |
    | policy_loss        | 5.709054e-05  |
    | serial_timesteps   | 52608         |
    | time_elapsed       | 252           |
    | total_timesteps    | 52608         |
    | value_loss         | 2.237869e+19  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 2.5131396e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 234           |
    | n_updates          | 412           |
    | policy_entropy     | 0.63782257    |
    | policy_loss        | 0.00012891181 |
    | serial_timesteps   | 52736         |
    | time_elapsed       | 253           |
    | total_timesteps    | 52736         |
    | value_loss         | 1.5741169e+19 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 9.540868e-07  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 229           |
    | n_updates          | 413           |
    | policy_entropy     | 0.6414834     |
    | policy_loss        | 5.8322912e-05 |
    | serial_timesteps   | 52864         |
    | time_elapsed       | 253           |
    | total_timesteps    | 52864         |
    | value_loss         | 9.253745e+18  |
    --------------------------------------
    -------------------------------------------
    | approxkl           | 7.558876e-08       |
    | clipfrac           | 0.0                |
    | explained_variance | -1.19e-07          |
    | fps                | 237                |
    | n_updates          | 414                |
    | policy_entropy     | 0.63728106         |
    | policy_loss        | 8.456875e-06       |
    | serial_timesteps   | 52992              |
    | time_elapsed       | 254                |
    | total_timesteps    | 52992              |
    | value_loss         | 1192971000000000.0 |
    -------------------------------------------
    -------------------------------------------
    | approxkl           | 3.4271437e-08      |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 216                |
    | n_updates          | 415                |
    | policy_entropy     | 0.6420794          |
    | policy_loss        | -1.069624e-06      |
    | serial_timesteps   | 53120              |
    | time_elapsed       | 255                |
    | total_timesteps    | 53120              |
    | value_loss         | 1043397700000000.0 |
    -------------------------------------------
    --------------------------------------
    | approxkl           | 6.8711495e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 232           |
    | n_updates          | 416           |
    | policy_entropy     | 0.6368166     |
    | policy_loss        | 2.3709494e-05 |
    | serial_timesteps   | 53248         |
    | time_elapsed       | 255           |
    | total_timesteps    | 53248         |
    | value_loss         | 4.9833153e+16 |
    --------------------------------------
    -------------------------------------------
    | approxkl           | 2.531091e-06       |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 227                |
    | n_updates          | 417                |
    | policy_entropy     | 0.6359738          |
    | policy_loss        | 4.922878e-05       |
    | serial_timesteps   | 53376              |
    | time_elapsed       | 256                |
    | total_timesteps    | 53376              |
    | value_loss         | 6753355600000000.0 |
    -------------------------------------------
    --------------------------------------
    | approxkl           | 9.776614e-07  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 228           |
    | n_updates          | 418           |
    | policy_entropy     | 0.6390319     |
    | policy_loss        | 0.00021519815 |
    | serial_timesteps   | 53504         |
    | time_elapsed       | 256           |
    | total_timesteps    | 53504         |
    | value_loss         | 5.9633375e+16 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 8.332546e-08  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 227           |
    | n_updates          | 419           |
    | policy_entropy     | 0.64046633    |
    | policy_loss        | -5.704374e-05 |
    | serial_timesteps   | 53632         |
    | time_elapsed       | 257           |
    | total_timesteps    | 53632         |
    | value_loss         | 1.8984886e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 5.689226e-07   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 186            |
    | n_updates          | 420            |
    | policy_entropy     | 0.63908625     |
    | policy_loss        | -1.0167598e-05 |
    | serial_timesteps   | 53760          |
    | time_elapsed       | 257            |
    | total_timesteps    | 53760          |
    | value_loss         | 3.226872e+18   |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 2.5526194e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 219           |
    | n_updates          | 421           |
    | policy_entropy     | 0.6425083     |
    | policy_loss        | 0.00013040158 |
    | serial_timesteps   | 53888         |
    | time_elapsed       | 258           |
    | total_timesteps    | 53888         |
    | value_loss         | 1.4191826e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 3.2704456e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 231           |
    | n_updates          | 422           |
    | policy_entropy     | 0.6407979     |
    | policy_loss        | 5.7421392e-05 |
    | serial_timesteps   | 54016         |
    | time_elapsed       | 259           |
    | total_timesteps    | 54016         |
    | value_loss         | 6.483248e+16  |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 6.1730416e-06  |
    | clipfrac           | 0.0            |
    | explained_variance | -1.19e-07      |
    | fps                | 244            |
    | n_updates          | 423            |
    | policy_entropy     | 0.6393147      |
    | policy_loss        | -0.00028288667 |
    | serial_timesteps   | 54144          |
    | time_elapsed       | 259            |
    | total_timesteps    | 54144          |
    | value_loss         | 5.5493984e+16  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 4.628431e-06  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 226           |
    | n_updates          | 424           |
    | policy_entropy     | 0.63281775    |
    | policy_loss        | -8.125906e-06 |
    | serial_timesteps   | 54272         |
    | time_elapsed       | 260           |
    | total_timesteps    | 54272         |
    | value_loss         | 3.7242153e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 5.07763e-06   |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 248           |
    | n_updates          | 425           |
    | policy_entropy     | 0.6309879     |
    | policy_loss        | 0.00035625708 |
    | serial_timesteps   | 54400         |
    | time_elapsed       | 260           |
    | total_timesteps    | 54400         |
    | value_loss         | 5.5537363e+17 |
    --------------------------------------
    -------------------------------------
    | approxkl           | 3.720819e-06 |
    | clipfrac           | 0.0          |
    | explained_variance | 0            |
    | fps                | 228          |
    | n_updates          | 426          |
    | policy_entropy     | 0.62904316   |
    | policy_loss        | 9.2651e-05   |
    | serial_timesteps   | 54528        |
    | time_elapsed       | 261          |
    | total_timesteps    | 54528        |
    | value_loss         | 7.816627e+17 |
    -------------------------------------
    ---------------------------------------
    | approxkl           | 1.6606228e-06  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 244            |
    | n_updates          | 427            |
    | policy_entropy     | 0.6276789      |
    | policy_loss        | -0.00010945776 |
    | serial_timesteps   | 54656          |
    | time_elapsed       | 261            |
    | total_timesteps    | 54656          |
    | value_loss         | 1.922564e+17   |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 5.2730445e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 230           |
    | n_updates          | 428           |
    | policy_entropy     | 0.6277158     |
    | policy_loss        | -3.631902e-05 |
    | serial_timesteps   | 54784         |
    | time_elapsed       | 262           |
    | total_timesteps    | 54784         |
    | value_loss         | 1.6040657e+18 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.4851645e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 244            |
    | n_updates          | 429            |
    | policy_entropy     | 0.62541354     |
    | policy_loss        | -3.5153702e-05 |
    | serial_timesteps   | 54912          |
    | time_elapsed       | 263            |
    | total_timesteps    | 54912          |
    | value_loss         | 1.1889694e+19  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 5.4191442e-09 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 233           |
    | n_updates          | 430           |
    | policy_entropy     | 0.6260421     |
    | policy_loss        | 1.4943071e-06 |
    | serial_timesteps   | 55040         |
    | time_elapsed       | 263           |
    | total_timesteps    | 55040         |
    | value_loss         | 1.1160764e+19 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.1532135e-09  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 238            |
    | n_updates          | 431            |
    | policy_entropy     | 0.62365663     |
    | policy_loss        | -9.3574636e-07 |
    | serial_timesteps   | 55168          |
    | time_elapsed       | 264            |
    | total_timesteps    | 55168          |
    | value_loss         | 1.617903e+19   |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 1.8391063e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 170           |
    | n_updates          | 432           |
    | policy_entropy     | 0.6251801     |
    | policy_loss        | 1.1686934e-05 |
    | serial_timesteps   | 55296         |
    | time_elapsed       | 264           |
    | total_timesteps    | 55296         |
    | value_loss         | 7.839168e+18  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 2.0238328e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 105           |
    | n_updates          | 433           |
    | policy_entropy     | 0.628301      |
    | policy_loss        | 2.0894688e-05 |
    | serial_timesteps   | 55424         |
    | time_elapsed       | 265           |
    | total_timesteps    | 55424         |
    | value_loss         | 1.3490856e+18 |
    --------------------------------------
    ------------------------------------------
    | approxkl           | 1.4683977e-07     |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 235               |
    | n_updates          | 434               |
    | policy_entropy     | 0.62566644        |
    | policy_loss        | 1.1228956e-05     |
    | serial_timesteps   | 55552             |
    | time_elapsed       | 266               |
    | total_timesteps    | 55552             |
    | value_loss         | 208625840000000.0 |
    ------------------------------------------
    -------------------------------------------
    | approxkl           | 4.0770652e-07      |
    | clipfrac           | 0.0                |
    | explained_variance | -1.19e-07          |
    | fps                | 241                |
    | n_updates          | 435                |
    | policy_entropy     | 0.6252606          |
    | policy_loss        | -6.179372e-05      |
    | serial_timesteps   | 55680              |
    | time_elapsed       | 267                |
    | total_timesteps    | 55680              |
    | value_loss         | 1641449500000000.0 |
    -------------------------------------------
    -------------------------------------------
    | approxkl           | 2.393071e-07       |
    | clipfrac           | 0.0                |
    | explained_variance | 5.96e-08           |
    | fps                | 235                |
    | n_updates          | 436                |
    | policy_entropy     | 0.62263393         |
    | policy_loss        | 5.7439902e-05      |
    | serial_timesteps   | 55808              |
    | time_elapsed       | 267                |
    | total_timesteps    | 55808              |
    | value_loss         | 1901941200000000.0 |
    -------------------------------------------
    ---------------------------------------
    | approxkl           | 1.5720515e-08  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 194            |
    | n_updates          | 437            |
    | policy_entropy     | 0.6204722      |
    | policy_loss        | -1.1215219e-05 |
    | serial_timesteps   | 55936          |
    | time_elapsed       | 268            |
    | total_timesteps    | 55936          |
    | value_loss         | 1.087126e+16   |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 3.2122532e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 218           |
    | n_updates          | 438           |
    | policy_entropy     | 0.62362635    |
    | policy_loss        | -9.003561e-06 |
    | serial_timesteps   | 56064         |
    | time_elapsed       | 268           |
    | total_timesteps    | 56064         |
    | value_loss         | 1.8029132e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.6991643e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 237           |
    | n_updates          | 439           |
    | policy_entropy     | 0.6251726     |
    | policy_loss        | 5.7544326e-05 |
    | serial_timesteps   | 56192         |
    | time_elapsed       | 269           |
    | total_timesteps    | 56192         |
    | value_loss         | 4.6317433e+18 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.09088845e-07 |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 211            |
    | n_updates          | 440            |
    | policy_entropy     | 0.6289015      |
    | policy_loss        | 2.6288908e-06  |
    | serial_timesteps   | 56320          |
    | time_elapsed       | 270            |
    | total_timesteps    | 56320          |
    | value_loss         | 3.05487e+18    |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 5.5113976e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 198           |
    | n_updates          | 441           |
    | policy_entropy     | 0.6261145     |
    | policy_loss        | 1.6897684e-05 |
    | serial_timesteps   | 56448         |
    | time_elapsed       | 270           |
    | total_timesteps    | 56448         |
    | value_loss         | 2.2483324e+17 |
    --------------------------------------
    -------------------------------------
    | approxkl           | 4.407807e-07 |
    | clipfrac           | 0.0          |
    | explained_variance | 0            |
    | fps                | 193          |
    | n_updates          | 442          |
    | policy_entropy     | 0.625765     |
    | policy_loss        | 4.683691e-05 |
    | serial_timesteps   | 56576        |
    | time_elapsed       | 271          |
    | total_timesteps    | 56576        |
    | value_loss         | 1.833267e+17 |
    -------------------------------------
    --------------------------------------
    | approxkl           | 9.62639e-07   |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 203           |
    | n_updates          | 443           |
    | policy_entropy     | 0.6280814     |
    | policy_loss        | -0.0001229723 |
    | serial_timesteps   | 56704         |
    | time_elapsed       | 271           |
    | total_timesteps    | 56704         |
    | value_loss         | 1.7648093e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.3206768e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 5.96e-08      |
    | fps                | 194           |
    | n_updates          | 444           |
    | policy_entropy     | 0.6227137     |
    | policy_loss        | 2.399087e-06  |
    | serial_timesteps   | 56832         |
    | time_elapsed       | 272           |
    | total_timesteps    | 56832         |
    | value_loss         | 5.879032e+17  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.9665458e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 5.96e-08      |
    | fps                | 233           |
    | n_updates          | 445           |
    | policy_entropy     | 0.62122154    |
    | policy_loss        | 0.00010095048 |
    | serial_timesteps   | 56960         |
    | time_elapsed       | 273           |
    | total_timesteps    | 56960         |
    | value_loss         | 7.619222e+16  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 8.8278705e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 238           |
    | n_updates          | 446           |
    | policy_entropy     | 0.6186576     |
    | policy_loss        | -7.584621e-05 |
    | serial_timesteps   | 57088         |
    | time_elapsed       | 273           |
    | total_timesteps    | 57088         |
    | value_loss         | 4.367021e+17  |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.0493669e-08  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 239            |
    | n_updates          | 447            |
    | policy_entropy     | 0.618618       |
    | policy_loss        | -1.1743978e-05 |
    | serial_timesteps   | 57216          |
    | time_elapsed       | 274            |
    | total_timesteps    | 57216          |
    | value_loss         | 5.4621165e+16  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 2.4654835e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 234           |
    | n_updates          | 448           |
    | policy_entropy     | 0.6213516     |
    | policy_loss        | 2.9590214e-05 |
    | serial_timesteps   | 57344         |
    | time_elapsed       | 274           |
    | total_timesteps    | 57344         |
    | value_loss         | 6.0645257e+18 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.1120175e-06  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 228            |
    | n_updates          | 449            |
    | policy_entropy     | 0.61938345     |
    | policy_loss        | -4.9775932e-05 |
    | serial_timesteps   | 57472          |
    | time_elapsed       | 275            |
    | total_timesteps    | 57472          |
    | value_loss         | 2.0319036e+19  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 7.4991846e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 235           |
    | n_updates          | 450           |
    | policy_entropy     | 0.62331766    |
    | policy_loss        | 0.00016118679 |
    | serial_timesteps   | 57600         |
    | time_elapsed       | 276           |
    | total_timesteps    | 57600         |
    | value_loss         | 1.1559413e+19 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 6.3156667e-09 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 226           |
    | n_updates          | 451           |
    | policy_entropy     | 0.6206722     |
    | policy_loss        | 5.8063306e-06 |
    | serial_timesteps   | 57728         |
    | time_elapsed       | 276           |
    | total_timesteps    | 57728         |
    | value_loss         | 2.3012281e+19 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 4.930201e-08  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 234           |
    | n_updates          | 452           |
    | policy_entropy     | 0.6241387     |
    | policy_loss        | 3.0404655e-05 |
    | serial_timesteps   | 57856         |
    | time_elapsed       | 277           |
    | total_timesteps    | 57856         |
    | value_loss         | 5.39565e+18   |
    --------------------------------------
    --------------------------------------
    | approxkl           | 7.769216e-08  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 229           |
    | n_updates          | 453           |
    | policy_entropy     | 0.6225493     |
    | policy_loss        | 4.4491608e-06 |
    | serial_timesteps   | 57984         |
    | time_elapsed       | 277           |
    | total_timesteps    | 57984         |
    | value_loss         | 6.7030256e+17 |
    --------------------------------------
    -------------------------------------------
    | approxkl           | 3.299744e-08       |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 237                |
    | n_updates          | 454                |
    | policy_entropy     | 0.6237309          |
    | policy_loss        | -6.468501e-06      |
    | serial_timesteps   | 58112              |
    | time_elapsed       | 278                |
    | total_timesteps    | 58112              |
    | value_loss         | 1318311400000000.0 |
    -------------------------------------------
    -------------------------------------------
    | approxkl           | 1.152019e-08       |
    | clipfrac           | 0.0                |
    | explained_variance | 5.96e-08           |
    | fps                | 234                |
    | n_updates          | 455                |
    | policy_entropy     | 0.61972606         |
    | policy_loss        | -9.131385e-06      |
    | serial_timesteps   | 58240              |
    | time_elapsed       | 278                |
    | total_timesteps    | 58240              |
    | value_loss         | 2580862500000000.0 |
    -------------------------------------------
    -------------------------------------------
    | approxkl           | 1.13889975e-07     |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 201                |
    | n_updates          | 456                |
    | policy_entropy     | 0.6185694          |
    | policy_loss        | -9.3025155e-05     |
    | serial_timesteps   | 58368              |
    | time_elapsed       | 279                |
    | total_timesteps    | 58368              |
    | value_loss         | 2700363500000000.0 |
    -------------------------------------------
    ---------------------------------------
    | approxkl           | 2.5750137e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 191            |
    | n_updates          | 457            |
    | policy_entropy     | 0.6193376      |
    | policy_loss        | -1.4691148e-05 |
    | serial_timesteps   | 58496          |
    | time_elapsed       | 279            |
    | total_timesteps    | 58496          |
    | value_loss         | 1.3704948e+16  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 1.4457126e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 196           |
    | n_updates          | 458           |
    | policy_entropy     | 0.6187818     |
    | policy_loss        | 1.3349578e-05 |
    | serial_timesteps   | 58624         |
    | time_elapsed       | 280           |
    | total_timesteps    | 58624         |
    | value_loss         | 1.0272257e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.453405e-07   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 219            |
    | n_updates          | 459            |
    | policy_entropy     | 0.6213025      |
    | policy_loss        | -1.7710612e-05 |
    | serial_timesteps   | 58752          |
    | time_elapsed       | 281            |
    | total_timesteps    | 58752          |
    | value_loss         | 1.0543942e+19  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 3.9600543e-08  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 223            |
    | n_updates          | 460            |
    | policy_entropy     | 0.62586224     |
    | policy_loss        | -3.2118987e-06 |
    | serial_timesteps   | 58880          |
    | time_elapsed       | 281            |
    | total_timesteps    | 58880          |
    | value_loss         | 7.771124e+17   |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 5.3331064e-09  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 227            |
    | n_updates          | 461            |
    | policy_entropy     | 0.6223165      |
    | policy_loss        | 2.4235342e-06  |
    | serial_timesteps   | 59008          |
    | time_elapsed       | 282            |
    | total_timesteps    | 59008          |
    | value_loss         | 1.18192965e+17 |
    ---------------------------------------
    -------------------------------------
    | approxkl           | 6.607495e-09 |
    | clipfrac           | 0.0          |
    | explained_variance | 0            |
    | fps                | 229          |
    | n_updates          | 462          |
    | policy_entropy     | 0.6251231    |
    | policy_loss        | 1.805136e-06 |
    | serial_timesteps   | 59136        |
    | time_elapsed       | 283          |
    | total_timesteps    | 59136        |
    | value_loss         | 2.928356e+17 |
    -------------------------------------
    ---------------------------------------
    | approxkl           | 5.531304e-07   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 228            |
    | n_updates          | 463            |
    | policy_entropy     | 0.621814       |
    | policy_loss        | -5.1319366e-05 |
    | serial_timesteps   | 59264          |
    | time_elapsed       | 283            |
    | total_timesteps    | 59264          |
    | value_loss         | 5.2262162e+17  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 1.6255749e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 235           |
    | n_updates          | 464           |
    | policy_entropy     | 0.6187353     |
    | policy_loss        | -2.442114e-05 |
    | serial_timesteps   | 59392         |
    | time_elapsed       | 284           |
    | total_timesteps    | 59392         |
    | value_loss         | 2.526444e+17  |
    --------------------------------------
    -------------------------------------
    | approxkl           | 6.360068e-07 |
    | clipfrac           | 0.0          |
    | explained_variance | -1.19e-07    |
    | fps                | 229          |
    | n_updates          | 465          |
    | policy_entropy     | 0.6186774    |
    | policy_loss        | 8.464884e-05 |
    | serial_timesteps   | 59520        |
    | time_elapsed       | 284          |
    | total_timesteps    | 59520        |
    | value_loss         | 7.225652e+17 |
    -------------------------------------
    ---------------------------------------
    | approxkl           | 1.3749803e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 222            |
    | n_updates          | 466            |
    | policy_entropy     | 0.6165291      |
    | policy_loss        | -2.0423904e-05 |
    | serial_timesteps   | 59648          |
    | time_elapsed       | 285            |
    | total_timesteps    | 59648          |
    | value_loss         | 1.7399718e+17  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 1.2375145e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 226           |
    | n_updates          | 467           |
    | policy_entropy     | 0.6208763     |
    | policy_loss        | -9.013573e-06 |
    | serial_timesteps   | 59776         |
    | time_elapsed       | 285           |
    | total_timesteps    | 59776         |
    | value_loss         | 2.7301264e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.5066798e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 186           |
    | n_updates          | 468           |
    | policy_entropy     | 0.6194458     |
    | policy_loss        | 0.00018484448 |
    | serial_timesteps   | 59904         |
    | time_elapsed       | 286           |
    | total_timesteps    | 59904         |
    | value_loss         | 1.2625828e+19 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 9.903267e-07   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 188            |
    | n_updates          | 469            |
    | policy_entropy     | 0.6226375      |
    | policy_loss        | -2.6465394e-05 |
    | serial_timesteps   | 60032          |
    | time_elapsed       | 287            |
    | total_timesteps    | 60032          |
    | value_loss         | 2.776797e+19   |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 4.537034e-07   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 192            |
    | n_updates          | 470            |
    | policy_entropy     | 0.6209501      |
    | policy_loss        | -2.0875363e-05 |
    | serial_timesteps   | 60160          |
    | time_elapsed       | 287            |
    | total_timesteps    | 60160          |
    | value_loss         | 1.2365174e+19  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 1.6801029e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 194           |
    | n_updates          | 471           |
    | policy_entropy     | 0.6239718     |
    | policy_loss        | 3.379956e-05  |
    | serial_timesteps   | 60288         |
    | time_elapsed       | 288           |
    | total_timesteps    | 60288         |
    | value_loss         | 4.744531e+18  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 2.493875e-06  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 193           |
    | n_updates          | 472           |
    | policy_entropy     | 0.6288806     |
    | policy_loss        | 2.6994385e-05 |
    | serial_timesteps   | 60416         |
    | time_elapsed       | 289           |
    | total_timesteps    | 60416         |
    | value_loss         | 2.4514838e+18 |
    --------------------------------------
    -------------------------------------------
    | approxkl           | 8.1273436e-07      |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 187                |
    | n_updates          | 473                |
    | policy_entropy     | 0.62512046         |
    | policy_loss        | 0.00011716038      |
    | serial_timesteps   | 60544              |
    | time_elapsed       | 289                |
    | total_timesteps    | 60544              |
    | value_loss         | 1252719400000000.0 |
    -------------------------------------------
    -------------------------------------------
    | approxkl           | 4.8721927e-07      |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 190                |
    | n_updates          | 474                |
    | policy_entropy     | 0.63084126         |
    | policy_loss        | -2.7780654e-05     |
    | serial_timesteps   | 60672              |
    | time_elapsed       | 290                |
    | total_timesteps    | 60672              |
    | value_loss         | 1273401400000000.0 |
    -------------------------------------------
    ------------------------------------------
    | approxkl           | 2.3656601e-07     |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 196               |
    | n_updates          | 475               |
    | policy_entropy     | 0.6259388         |
    | policy_loss        | -3.8377708e-05    |
    | serial_timesteps   | 60800             |
    | time_elapsed       | 291               |
    | total_timesteps    | 60800             |
    | value_loss         | 277254470000000.0 |
    ------------------------------------------
    -------------------------------------------
    | approxkl           | 4.2601847e-08      |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 188                |
    | n_updates          | 476                |
    | policy_entropy     | 0.62298965         |
    | policy_loss        | 2.1686079e-05      |
    | serial_timesteps   | 60928              |
    | time_elapsed       | 291                |
    | total_timesteps    | 60928              |
    | value_loss         | 6879577700000000.0 |
    -------------------------------------------
    ---------------------------------------
    | approxkl           | 3.8953104e-08  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 186            |
    | n_updates          | 477            |
    | policy_entropy     | 0.6261706      |
    | policy_loss        | -2.4447218e-08 |
    | serial_timesteps   | 61056          |
    | time_elapsed       | 292            |
    | total_timesteps    | 61056          |
    | value_loss         | 9.313405e+16   |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 8.971215e-09  |
    | clipfrac           | 0.0           |
    | explained_variance | -1.19e-07     |
    | fps                | 199           |
    | n_updates          | 478           |
    | policy_entropy     | 0.6273325     |
    | policy_loss        | 2.164417e-05  |
    | serial_timesteps   | 61184         |
    | time_elapsed       | 293           |
    | total_timesteps    | 61184         |
    | value_loss         | 1.8378598e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 4.2267797e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 198            |
    | n_updates          | 479            |
    | policy_entropy     | 0.6274052      |
    | policy_loss        | -0.00013276981 |
    | serial_timesteps   | 61312          |
    | time_elapsed       | 293            |
    | total_timesteps    | 61312          |
    | value_loss         | 2.5092194e+18  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 2.979251e-08   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 192            |
    | n_updates          | 480            |
    | policy_entropy     | 0.6343225      |
    | policy_loss        | -1.1013704e-05 |
    | serial_timesteps   | 61440          |
    | time_elapsed       | 294            |
    | total_timesteps    | 61440          |
    | value_loss         | 4.3565097e+17  |
    ---------------------------------------
    ----------------------------------------
    | approxkl           | 2.2176201e-07   |
    | clipfrac           | 0.0             |
    | explained_variance | 0               |
    | fps                | 189             |
    | n_updates          | 481             |
    | policy_entropy     | 0.63299286      |
    | policy_loss        | -0.000113601796 |
    | serial_timesteps   | 61568           |
    | time_elapsed       | 295             |
    | total_timesteps    | 61568           |
    | value_loss         | 2.8484713e+17   |
    ----------------------------------------
    ---------------------------------------
    | approxkl           | 1.13000794e-07 |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 198            |
    | n_updates          | 482            |
    | policy_entropy     | 0.6338711      |
    | policy_loss        | -4.755007e-05  |
    | serial_timesteps   | 61696          |
    | time_elapsed       | 295            |
    | total_timesteps    | 61696          |
    | value_loss         | 1.283256e+17   |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 1.6794972e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 189           |
    | n_updates          | 483           |
    | policy_entropy     | 0.6266495     |
    | policy_loss        | 1.817965e-05  |
    | serial_timesteps   | 61824         |
    | time_elapsed       | 296           |
    | total_timesteps    | 61824         |
    | value_loss         | 7.665575e+17  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 4.3784823e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 177           |
    | n_updates          | 484           |
    | policy_entropy     | 0.6302514     |
    | policy_loss        | 2.8140843e-05 |
    | serial_timesteps   | 61952         |
    | time_elapsed       | 297           |
    | total_timesteps    | 61952         |
    | value_loss         | 4.9232056e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 2.2782917e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 192           |
    | n_updates          | 485           |
    | policy_entropy     | 0.6301503     |
    | policy_loss        | 1.6753562e-05 |
    | serial_timesteps   | 62080         |
    | time_elapsed       | 297           |
    | total_timesteps    | 62080         |
    | value_loss         | 6.0543584e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 3.7455044e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 186           |
    | n_updates          | 486           |
    | policy_entropy     | 0.63061166    |
    | policy_loss        | 1.2379256e-05 |
    | serial_timesteps   | 62208         |
    | time_elapsed       | 298           |
    | total_timesteps    | 62208         |
    | value_loss         | 4.0376166e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 7.10781e-07   |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 194           |
    | n_updates          | 487           |
    | policy_entropy     | 0.6312884     |
    | policy_loss        | 0.00010158401 |
    | serial_timesteps   | 62336         |
    | time_elapsed       | 299           |
    | total_timesteps    | 62336         |
    | value_loss         | 4.058357e+18  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 9.3632735e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 190           |
    | n_updates          | 488           |
    | policy_entropy     | 0.6283406     |
    | policy_loss        | -7.058494e-05 |
    | serial_timesteps   | 62464         |
    | time_elapsed       | 299           |
    | total_timesteps    | 62464         |
    | value_loss         | 2.016336e+19  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.0001263e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 197           |
    | n_updates          | 489           |
    | policy_entropy     | 0.6344956     |
    | policy_loss        | 2.4617882e-05 |
    | serial_timesteps   | 62592         |
    | time_elapsed       | 300           |
    | total_timesteps    | 62592         |
    | value_loss         | 2.7762814e+19 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 4.6185312e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 206           |
    | n_updates          | 490           |
    | policy_entropy     | 0.6315846     |
    | policy_loss        | 8.3416e-05    |
    | serial_timesteps   | 62720         |
    | time_elapsed       | 301           |
    | total_timesteps    | 62720         |
    | value_loss         | 3.3344128e+19 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 4.285197e-09  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 191           |
    | n_updates          | 491           |
    | policy_entropy     | 0.63512015    |
    | policy_loss        | 1.8953579e-06 |
    | serial_timesteps   | 62848         |
    | time_elapsed       | 301           |
    | total_timesteps    | 62848         |
    | value_loss         | 5.1893e+18    |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.703984e-09   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 185            |
    | n_updates          | 492            |
    | policy_entropy     | 0.63829714     |
    | policy_loss        | -5.3131953e-07 |
    | serial_timesteps   | 62976          |
    | time_elapsed       | 302            |
    | total_timesteps    | 62976          |
    | value_loss         | 5.7602425e+18  |
    ---------------------------------------
    -------------------------------------------
    | approxkl           | 1.3163643e-07      |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 191                |
    | n_updates          | 493                |
    | policy_entropy     | 0.6336285          |
    | policy_loss        | -8.772826e-06      |
    | serial_timesteps   | 63104              |
    | time_elapsed       | 303                |
    | total_timesteps    | 63104              |
    | value_loss         | 1225812900000000.0 |
    -------------------------------------------
    ------------------------------------------
    | approxkl           | 6.598103e-08      |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 193               |
    | n_updates          | 494               |
    | policy_entropy     | 0.6351327         |
    | policy_loss        | 6.276765e-06      |
    | serial_timesteps   | 63232             |
    | time_elapsed       | 303               |
    | total_timesteps    | 63232             |
    | value_loss         | 685182840000000.0 |
    ------------------------------------------
    ------------------------------------------
    | approxkl           | 2.0512534e-08     |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 202               |
    | n_updates          | 495               |
    | policy_entropy     | 0.6337029         |
    | policy_loss        | -3.1562522e-06    |
    | serial_timesteps   | 63360             |
    | time_elapsed       | 304               |
    | total_timesteps    | 63360             |
    | value_loss         | 925493900000000.0 |
    ------------------------------------------
    -------------------------------------------
    | approxkl           | 2.0783483e-07      |
    | clipfrac           | 0.0                |
    | explained_variance | -1.19e-07          |
    | fps                | 228                |
    | n_updates          | 496                |
    | policy_entropy     | 0.63118553         |
    | policy_loss        | 3.297231e-05       |
    | serial_timesteps   | 63488              |
    | time_elapsed       | 305                |
    | total_timesteps    | 63488              |
    | value_loss         | 3628194000000000.0 |
    -------------------------------------------
    --------------------------------------
    | approxkl           | 3.1459243e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 233           |
    | n_updates          | 497           |
    | policy_entropy     | 0.63370067    |
    | policy_loss        | -3.192341e-05 |
    | serial_timesteps   | 63616         |
    | time_elapsed       | 305           |
    | total_timesteps    | 63616         |
    | value_loss         | 1.2289411e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 4.4408114e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 228            |
    | n_updates          | 498            |
    | policy_entropy     | 0.63447094     |
    | policy_loss        | -4.8678135e-05 |
    | serial_timesteps   | 63744          |
    | time_elapsed       | 306            |
    | total_timesteps    | 63744          |
    | value_loss         | 1.04834764e+18 |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 4.63239e-07    |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 232            |
    | n_updates          | 499            |
    | policy_entropy     | 0.63983214     |
    | policy_loss        | -1.4061341e-05 |
    | serial_timesteps   | 63872          |
    | time_elapsed       | 306            |
    | total_timesteps    | 63872          |
    | value_loss         | 2.9385336e+18  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 6.065245e-07  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 226           |
    | n_updates          | 500           |
    | policy_entropy     | 0.6396425     |
    | policy_loss        | -8.631009e-05 |
    | serial_timesteps   | 64000         |
    | time_elapsed       | 307           |
    | total_timesteps    | 64000         |
    | value_loss         | 3.35231e+17   |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 2.609828e-07   |
    | clipfrac           | 0.0            |
    | explained_variance | 1.19e-07       |
    | fps                | 239            |
    | n_updates          | 501            |
    | policy_entropy     | 0.64097774     |
    | policy_loss        | -5.3842086e-05 |
    | serial_timesteps   | 64128          |
    | time_elapsed       | 307            |
    | total_timesteps    | 64128          |
    | value_loss         | 1.05562204e+17 |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 8.535136e-08  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 220           |
    | n_updates          | 502           |
    | policy_entropy     | 0.6426721     |
    | policy_loss        | 2.863817e-05  |
    | serial_timesteps   | 64256         |
    | time_elapsed       | 308           |
    | total_timesteps    | 64256         |
    | value_loss         | 6.9174056e+16 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.8341856e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 228           |
    | n_updates          | 503           |
    | policy_entropy     | 0.6372534     |
    | policy_loss        | 6.3288026e-06 |
    | serial_timesteps   | 64384         |
    | time_elapsed       | 309           |
    | total_timesteps    | 64384         |
    | value_loss         | 4.9631075e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 5.0509605e-09 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 217           |
    | n_updates          | 504           |
    | policy_entropy     | 0.64059865    |
    | policy_loss        | 9.883661e-07  |
    | serial_timesteps   | 64512         |
    | time_elapsed       | 309           |
    | total_timesteps    | 64512         |
    | value_loss         | 2.8511642e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 8.704014e-08   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 191            |
    | n_updates          | 505            |
    | policy_entropy     | 0.6388066      |
    | policy_loss        | -1.8182327e-05 |
    | serial_timesteps   | 64640          |
    | time_elapsed       | 310            |
    | total_timesteps    | 64640          |
    | value_loss         | 9.0176006e+17  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 2.3999993e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 215           |
    | n_updates          | 506           |
    | policy_entropy     | 0.63957655    |
    | policy_loss        | 6.131176e-05  |
    | serial_timesteps   | 64768         |
    | time_elapsed       | 310           |
    | total_timesteps    | 64768         |
    | value_loss         | 1.1917824e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 3.463692e-07   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 219            |
    | n_updates          | 507            |
    | policy_entropy     | 0.63914585     |
    | policy_loss        | -6.4151827e-06 |
    | serial_timesteps   | 64896          |
    | time_elapsed       | 311            |
    | total_timesteps    | 64896          |
    | value_loss         | 7.0196357e+18  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 1.5792793e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 234           |
    | n_updates          | 508           |
    | policy_entropy     | 0.6380417     |
    | policy_loss        | 2.6598223e-05 |
    | serial_timesteps   | 65024         |
    | time_elapsed       | 312           |
    | total_timesteps    | 65024         |
    | value_loss         | 5.485684e+19  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 2.1704365e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 222           |
    | n_updates          | 509           |
    | policy_entropy     | 0.64220774    |
    | policy_loss        | 3.2881508e-05 |
    | serial_timesteps   | 65152         |
    | time_elapsed       | 312           |
    | total_timesteps    | 65152         |
    | value_loss         | 1.0922498e+19 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 4.3568184e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 226            |
    | n_updates          | 510            |
    | policy_entropy     | 0.64050883     |
    | policy_loss        | -3.6088284e-05 |
    | serial_timesteps   | 65280          |
    | time_elapsed       | 313            |
    | total_timesteps    | 65280          |
    | value_loss         | 9.631481e+18   |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 1.6800463e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 221            |
    | n_updates          | 511            |
    | policy_entropy     | 0.64482963     |
    | policy_loss        | -1.0106247e-05 |
    | serial_timesteps   | 65408          |
    | time_elapsed       | 313            |
    | total_timesteps    | 65408          |
    | value_loss         | 2.5395383e+19  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 2.0661595e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 226           |
    | n_updates          | 512           |
    | policy_entropy     | 0.64245516    |
    | policy_loss        | 6.6203065e-06 |
    | serial_timesteps   | 65536         |
    | time_elapsed       | 314           |
    | total_timesteps    | 65536         |
    | value_loss         | 2.3343115e+17 |
    --------------------------------------
    ------------------------------------------
    | approxkl           | 3.0976167e-08     |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 206               |
    | n_updates          | 513               |
    | policy_entropy     | 0.64484996        |
    | policy_loss        | 1.5067635e-05     |
    | serial_timesteps   | 65664             |
    | time_elapsed       | 314               |
    | total_timesteps    | 65664             |
    | value_loss         | 335121000000000.0 |
    ------------------------------------------
    -------------------------------------------
    | approxkl           | 6.1659776e-08      |
    | clipfrac           | 0.0                |
    | explained_variance | 1.19e-07           |
    | fps                | 193                |
    | n_updates          | 514                |
    | policy_entropy     | 0.64142334         |
    | policy_loss        | 3.7526246e-05      |
    | serial_timesteps   | 65792              |
    | time_elapsed       | 315                |
    | total_timesteps    | 65792              |
    | value_loss         | 2459380400000000.0 |
    -------------------------------------------
    -------------------------------------------
    | approxkl           | 1.2798e-07         |
    | clipfrac           | 0.0                |
    | explained_variance | -1.19e-07          |
    | fps                | 185                |
    | n_updates          | 515                |
    | policy_entropy     | 0.6411294          |
    | policy_loss        | 5.394686e-06       |
    | serial_timesteps   | 65920              |
    | time_elapsed       | 316                |
    | total_timesteps    | 65920              |
    | value_loss         | 3198100800000000.0 |
    -------------------------------------------
    ---------------------------------------
    | approxkl           | 2.4595792e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 193            |
    | n_updates          | 516            |
    | policy_entropy     | 0.64245594     |
    | policy_loss        | -1.8258579e-06 |
    | serial_timesteps   | 66048          |
    | time_elapsed       | 316            |
    | total_timesteps    | 66048          |
    | value_loss         | 5.0510774e+16  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 7.896733e-07  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 187           |
    | n_updates          | 517           |
    | policy_entropy     | 0.64043635    |
    | policy_loss        | 6.8903435e-05 |
    | serial_timesteps   | 66176         |
    | time_elapsed       | 317           |
    | total_timesteps    | 66176         |
    | value_loss         | 1.002205e+17  |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 6.3255175e-06  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 235            |
    | n_updates          | 518            |
    | policy_entropy     | 0.6397259      |
    | policy_loss        | -0.00014711288 |
    | serial_timesteps   | 66304          |
    | time_elapsed       | 318            |
    | total_timesteps    | 66304          |
    | value_loss         | 7.8102643e+18  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 4.7722056e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 230           |
    | n_updates          | 519           |
    | policy_entropy     | 0.64356256    |
    | policy_loss        | 0.00029706536 |
    | serial_timesteps   | 66432         |
    | time_elapsed       | 318           |
    | total_timesteps    | 66432         |
    | value_loss         | 4.7817266e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 5.4654056e-06  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 234            |
    | n_updates          | 520            |
    | policy_entropy     | 0.6394315      |
    | policy_loss        | -0.00011452637 |
    | serial_timesteps   | 66560          |
    | time_elapsed       | 319            |
    | total_timesteps    | 66560          |
    | value_loss         | 1.4218355e+17  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 2.5797692e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 1.19e-07      |
    | fps                | 224           |
    | n_updates          | 521           |
    | policy_entropy     | 0.6393347     |
    | policy_loss        | -6.371946e-05 |
    | serial_timesteps   | 66688         |
    | time_elapsed       | 319           |
    | total_timesteps    | 66688         |
    | value_loss         | 1.9678025e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 2.6778707e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 236           |
    | n_updates          | 522           |
    | policy_entropy     | 0.63349533    |
    | policy_loss        | -8.701184e-05 |
    | serial_timesteps   | 66816         |
    | time_elapsed       | 320           |
    | total_timesteps    | 66816         |
    | value_loss         | 1.0872094e+18 |
    --------------------------------------
    ----------------------------------------
    | approxkl           | 1.3953343e-06   |
    | clipfrac           | 0.0             |
    | explained_variance | 0               |
    | fps                | 213             |
    | n_updates          | 523             |
    | policy_entropy     | 0.6312664       |
    | policy_loss        | -1.34764705e-05 |
    | serial_timesteps   | 66944           |
    | time_elapsed       | 321             |
    | total_timesteps    | 66944           |
    | value_loss         | 4.2094782e+17   |
    ----------------------------------------
    --------------------------------------
    | approxkl           | 7.9935603e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 200           |
    | n_updates          | 524           |
    | policy_entropy     | 0.63235956    |
    | policy_loss        | -6.723276e-05 |
    | serial_timesteps   | 67072         |
    | time_elapsed       | 321           |
    | total_timesteps    | 67072         |
    | value_loss         | 7.636816e+17  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 3.8654747e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 226           |
    | n_updates          | 525           |
    | policy_entropy     | 0.6292793     |
    | policy_loss        | 2.4718582e-05 |
    | serial_timesteps   | 67200         |
    | time_elapsed       | 322           |
    | total_timesteps    | 67200         |
    | value_loss         | 2.0978716e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 2.369163e-09  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 228           |
    | n_updates          | 526           |
    | policy_entropy     | 0.6330651     |
    | policy_loss        | 4.996895e-06  |
    | serial_timesteps   | 67328         |
    | time_elapsed       | 322           |
    | total_timesteps    | 67328         |
    | value_loss         | 5.6278482e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 7.879867e-08  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 236           |
    | n_updates          | 527           |
    | policy_entropy     | 0.62613857    |
    | policy_loss        | 3.7180027e-05 |
    | serial_timesteps   | 67456         |
    | time_elapsed       | 323           |
    | total_timesteps    | 67456         |
    | value_loss         | 2.1081073e+19 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 3.480081e-08   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 225            |
    | n_updates          | 528            |
    | policy_entropy     | 0.63155043     |
    | policy_loss        | 1.30736735e-05 |
    | serial_timesteps   | 67584          |
    | time_elapsed       | 324            |
    | total_timesteps    | 67584          |
    | value_loss         | 1.9569359e+19  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 8.779359e-09  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 198           |
    | n_updates          | 529           |
    | policy_entropy     | 0.6284349     |
    | policy_loss        | 5.709706e-06  |
    | serial_timesteps   | 67712         |
    | time_elapsed       | 324           |
    | total_timesteps    | 67712         |
    | value_loss         | 2.5637451e+19 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.119314e-07  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 186           |
    | n_updates          | 530           |
    | policy_entropy     | 0.632275      |
    | policy_loss        | 2.2624503e-05 |
    | serial_timesteps   | 67840         |
    | time_elapsed       | 325           |
    | total_timesteps    | 67840         |
    | value_loss         | 1.2192999e+19 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 4.572795e-08  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 194           |
    | n_updates          | 531           |
    | policy_entropy     | 0.63545305    |
    | policy_loss        | 3.8580038e-06 |
    | serial_timesteps   | 67968         |
    | time_elapsed       | 325           |
    | total_timesteps    | 67968         |
    | value_loss         | 1.5234044e+19 |
    --------------------------------------
    -------------------------------------------
    | approxkl           | 1.5986652e-08      |
    | clipfrac           | 0.0                |
    | explained_variance | 1.19e-07           |
    | fps                | 201                |
    | n_updates          | 532                |
    | policy_entropy     | 0.6295162          |
    | policy_loss        | -2.0937528e-05     |
    | serial_timesteps   | 68096              |
    | time_elapsed       | 326                |
    | total_timesteps    | 68096              |
    | value_loss         | 1685326100000000.0 |
    -------------------------------------------
    -------------------------------------------
    | approxkl           | 8.124715e-09       |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 194                |
    | n_updates          | 533                |
    | policy_entropy     | 0.6350696          |
    | policy_loss        | 1.1835829e-05      |
    | serial_timesteps   | 68224              |
    | time_elapsed       | 327                |
    | total_timesteps    | 68224              |
    | value_loss         | 1350914600000000.0 |
    -------------------------------------------
    ------------------------------------------
    | approxkl           | 4.0458248e-10     |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 189               |
    | n_updates          | 534               |
    | policy_entropy     | 0.6287494         |
    | policy_loss        | -1.0661315e-06    |
    | serial_timesteps   | 68352             |
    | time_elapsed       | 327               |
    | total_timesteps    | 68352             |
    | value_loss         | 344353730000000.0 |
    ------------------------------------------
    -------------------------------------------
    | approxkl           | 7.301118e-08       |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 197                |
    | n_updates          | 535                |
    | policy_entropy     | 0.62573755         |
    | policy_loss        | 6.753835e-06       |
    | serial_timesteps   | 68480              |
    | time_elapsed       | 328                |
    | total_timesteps    | 68480              |
    | value_loss         | 6110314700000000.0 |
    -------------------------------------------
    --------------------------------------
    | approxkl           | 4.7093444e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 200           |
    | n_updates          | 536           |
    | policy_entropy     | 0.62908894    |
    | policy_loss        | -3.862183e-05 |
    | serial_timesteps   | 68608         |
    | time_elapsed       | 329           |
    | total_timesteps    | 68608         |
    | value_loss         | 7.628731e+16  |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 2.854419e-07   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 230            |
    | n_updates          | 537            |
    | policy_entropy     | 0.62992924     |
    | policy_loss        | -5.4951757e-05 |
    | serial_timesteps   | 68736          |
    | time_elapsed       | 329            |
    | total_timesteps    | 68736          |
    | value_loss         | 4.882333e+17   |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 1.9601093e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 230            |
    | n_updates          | 538            |
    | policy_entropy     | 0.62895703     |
    | policy_loss        | -2.4153385e-05 |
    | serial_timesteps   | 68864          |
    | time_elapsed       | 330            |
    | total_timesteps    | 68864          |
    | value_loss         | 7.3384056e+18  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 5.5177804e-08  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 234            |
    | n_updates          | 539            |
    | policy_entropy     | 0.6354817      |
    | policy_loss        | -4.2051543e-06 |
    | serial_timesteps   | 68992          |
    | time_elapsed       | 330            |
    | total_timesteps    | 68992          |
    | value_loss         | 2.5371334e+17  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 6.121698e-08  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 226           |
    | n_updates          | 540           |
    | policy_entropy     | 0.6347785     |
    | policy_loss        | 2.7917325e-05 |
    | serial_timesteps   | 69120         |
    | time_elapsed       | 331           |
    | total_timesteps    | 69120         |
    | value_loss         | 2.1891368e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.8777108e-08  |
    | clipfrac           | 0.0            |
    | explained_variance | 5.96e-08       |
    | fps                | 230            |
    | n_updates          | 541            |
    | policy_entropy     | 0.63546336     |
    | policy_loss        | -6.7898072e-06 |
    | serial_timesteps   | 69248          |
    | time_elapsed       | 332            |
    | total_timesteps    | 69248          |
    | value_loss         | 3.9275616e+16  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 3.457985e-07  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 231           |
    | n_updates          | 542           |
    | policy_entropy     | 0.626168      |
    | policy_loss        | 1.1513708e-05 |
    | serial_timesteps   | 69376         |
    | time_elapsed       | 332           |
    | total_timesteps    | 69376         |
    | value_loss         | 5.3329712e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.0829458e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 220           |
    | n_updates          | 543           |
    | policy_entropy     | 0.63290006    |
    | policy_loss        | 0.00016999478 |
    | serial_timesteps   | 69504         |
    | time_elapsed       | 333           |
    | total_timesteps    | 69504         |
    | value_loss         | 2.2024032e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 2.583804e-07  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 239           |
    | n_updates          | 544           |
    | policy_entropy     | 0.6337406     |
    | policy_loss        | -6.886432e-06 |
    | serial_timesteps   | 69632         |
    | time_elapsed       | 333           |
    | total_timesteps    | 69632         |
    | value_loss         | 2.9623424e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 2.5659757e-09  |
    | clipfrac           | 0.0            |
    | explained_variance | 5.96e-08       |
    | fps                | 215            |
    | n_updates          | 545            |
    | policy_entropy     | 0.63376355     |
    | policy_loss        | -7.3513947e-06 |
    | serial_timesteps   | 69760          |
    | time_elapsed       | 334            |
    | total_timesteps    | 69760          |
    | value_loss         | 1.7019358e+17  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 5.6724616e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 231           |
    | n_updates          | 546           |
    | policy_entropy     | 0.6330362     |
    | policy_loss        | -1.937151e-06 |
    | serial_timesteps   | 69888         |
    | time_elapsed       | 334           |
    | total_timesteps    | 69888         |
    | value_loss         | 5.386622e+18  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 6.105916e-08  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 199           |
    | n_updates          | 547           |
    | policy_entropy     | 0.6275419     |
    | policy_loss        | 2.9257499e-06 |
    | serial_timesteps   | 70016         |
    | time_elapsed       | 335           |
    | total_timesteps    | 70016         |
    | value_loss         | 4.644546e+19  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.6506748e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 195           |
    | n_updates          | 548           |
    | policy_entropy     | 0.63495666    |
    | policy_loss        | 1.4587538e-05 |
    | serial_timesteps   | 70144         |
    | time_elapsed       | 336           |
    | total_timesteps    | 70144         |
    | value_loss         | 1.372846e+19  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 2.1515116e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 192           |
    | n_updates          | 549           |
    | policy_entropy     | 0.63247395    |
    | policy_loss        | -9.612134e-05 |
    | serial_timesteps   | 70272         |
    | time_elapsed       | 336           |
    | total_timesteps    | 70272         |
    | value_loss         | 7.184942e+18  |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.6225889e-06  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 184            |
    | n_updates          | 550            |
    | policy_entropy     | 0.6372758      |
    | policy_loss        | -0.00021481747 |
    | serial_timesteps   | 70400          |
    | time_elapsed       | 337            |
    | total_timesteps    | 70400          |
    | value_loss         | 4.1572458e+18  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 2.9069398e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 178            |
    | n_updates          | 551            |
    | policy_entropy     | 0.64091593     |
    | policy_loss        | -1.4962396e-05 |
    | serial_timesteps   | 70528          |
    | time_elapsed       | 338            |
    | total_timesteps    | 70528          |
    | value_loss         | 2.544658e+18   |
    ---------------------------------------
    ------------------------------------------
    | approxkl           | 5.560516e-08      |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 186               |
    | n_updates          | 552               |
    | policy_entropy     | 0.6361704         |
    | policy_loss        | -3.0224095e-05    |
    | serial_timesteps   | 70656             |
    | time_elapsed       | 338               |
    | total_timesteps    | 70656             |
    | value_loss         | 493991330000000.0 |
    ------------------------------------------
    -------------------------------------------
    | approxkl           | 3.327603e-07       |
    | clipfrac           | 0.0                |
    | explained_variance | -1.19e-07          |
    | fps                | 218                |
    | n_updates          | 553                |
    | policy_entropy     | 0.6366631          |
    | policy_loss        | -2.3893546e-05     |
    | serial_timesteps   | 70784              |
    | time_elapsed       | 339                |
    | total_timesteps    | 70784              |
    | value_loss         | 2545731500000000.0 |
    -------------------------------------------
    ------------------------------------------
    | approxkl           | 7.629379e-08      |
    | clipfrac           | 0.0               |
    | explained_variance | 2.38e-07          |
    | fps                | 224               |
    | n_updates          | 554               |
    | policy_entropy     | 0.63469493        |
    | policy_loss        | -2.1300279e-05    |
    | serial_timesteps   | 70912             |
    | time_elapsed       | 340               |
    | total_timesteps    | 70912             |
    | value_loss         | 643014700000000.0 |
    ------------------------------------------
    -------------------------------------------
    | approxkl           | 3.3787825e-07      |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 226                |
    | n_updates          | 555                |
    | policy_entropy     | 0.6329825          |
    | policy_loss        | 2.5885063e-05      |
    | serial_timesteps   | 71040              |
    | time_elapsed       | 340                |
    | total_timesteps    | 71040              |
    | value_loss         | 6888538000000000.0 |
    -------------------------------------------
    --------------------------------------
    | approxkl           | 1.0656069e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | -1.19e-07     |
    | fps                | 240           |
    | n_updates          | 556           |
    | policy_entropy     | 0.63450193    |
    | policy_loss        | 5.992828e-06  |
    | serial_timesteps   | 71168         |
    | time_elapsed       | 341           |
    | total_timesteps    | 71168         |
    | value_loss         | 1.1474853e+17 |
    --------------------------------------
    -------------------------------------
    | approxkl           | 2.750268e-08 |
    | clipfrac           | 0.0          |
    | explained_variance | 0            |
    | fps                | 231          |
    | n_updates          | 557          |
    | policy_entropy     | 0.6342378    |
    | policy_loss        | -8.28132e-06 |
    | serial_timesteps   | 71296        |
    | time_elapsed       | 341          |
    | total_timesteps    | 71296        |
    | value_loss         | 6.732859e+18 |
    -------------------------------------
    --------------------------------------
    | approxkl           | 4.1775476e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 237           |
    | n_updates          | 558           |
    | policy_entropy     | 0.6377306     |
    | policy_loss        | 9.215437e-07  |
    | serial_timesteps   | 71424         |
    | time_elapsed       | 342           |
    | total_timesteps    | 71424         |
    | value_loss         | 1.6899624e+18 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.8017681e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 232           |
    | n_updates          | 559           |
    | policy_entropy     | 0.63846004    |
    | policy_loss        | 1.9615516e-05 |
    | serial_timesteps   | 71552         |
    | time_elapsed       | 342           |
    | total_timesteps    | 71552         |
    | value_loss         | 2.9618088e+17 |
    --------------------------------------
    -------------------------------------
    | approxkl           | 6.299815e-07 |
    | clipfrac           | 0.0          |
    | explained_variance | 0            |
    | fps                | 209          |
    | n_updates          | 560          |
    | policy_entropy     | 0.6389773    |
    | policy_loss        | 8.314953e-05 |
    | serial_timesteps   | 71680        |
    | time_elapsed       | 343          |
    | total_timesteps    | 71680        |
    | value_loss         | 7.312615e+16 |
    -------------------------------------
    --------------------------------------
    | approxkl           | 2.0967848e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | -1.19e-07     |
    | fps                | 220           |
    | n_updates          | 561           |
    | policy_entropy     | 0.6391501     |
    | policy_loss        | 1.4044577e-05 |
    | serial_timesteps   | 71808         |
    | time_elapsed       | 344           |
    | total_timesteps    | 71808         |
    | value_loss         | 8.954488e+16  |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 6.246032e-07   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 228            |
    | n_updates          | 562            |
    | policy_entropy     | 0.6335271      |
    | policy_loss        | -2.1702377e-05 |
    | serial_timesteps   | 71936          |
    | time_elapsed       | 344            |
    | total_timesteps    | 71936          |
    | value_loss         | 5.820599e+17   |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 1.0128484e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | -1.19e-07     |
    | fps                | 230           |
    | n_updates          | 563           |
    | policy_entropy     | 0.63807285    |
    | policy_loss        | -6.385869e-05 |
    | serial_timesteps   | 72064         |
    | time_elapsed       | 345           |
    | total_timesteps    | 72064         |
    | value_loss         | 3.0568093e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 7.459139e-07   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 228            |
    | n_updates          | 564            |
    | policy_entropy     | 0.63693285     |
    | policy_loss        | -0.00012486498 |
    | serial_timesteps   | 72192          |
    | time_elapsed       | 345            |
    | total_timesteps    | 72192          |
    | value_loss         | 8.1083554e+17  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 5.894493e-07   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 231            |
    | n_updates          | 565            |
    | policy_entropy     | 0.6393156      |
    | policy_loss        | -6.2149484e-06 |
    | serial_timesteps   | 72320          |
    | time_elapsed       | 346            |
    | total_timesteps    | 72320          |
    | value_loss         | 9.1205366e+16  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 3.2463655e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 227            |
    | n_updates          | 566            |
    | policy_entropy     | 0.63804305     |
    | policy_loss        | -1.8747174e-05 |
    | serial_timesteps   | 72448          |
    | time_elapsed       | 346            |
    | total_timesteps    | 72448          |
    | value_loss         | 8.348702e+18   |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 6.9074005e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 233           |
    | n_updates          | 567           |
    | policy_entropy     | 0.63665456    |
    | policy_loss        | 8.4377825e-07 |
    | serial_timesteps   | 72576         |
    | time_elapsed       | 347           |
    | total_timesteps    | 72576         |
    | value_loss         | 1.5591517e+19 |
    --------------------------------------
    -------------------------------------
    | approxkl           | 8.839514e-08 |
    | clipfrac           | 0.0          |
    | explained_variance | 0            |
    | fps                | 232          |
    | n_updates          | 568          |
    | policy_entropy     | 0.6411102    |
    | policy_loss        | 9.363284e-06 |
    | serial_timesteps   | 72704        |
    | time_elapsed       | 348          |
    | total_timesteps    | 72704        |
    | value_loss         | 8.132963e+18 |
    -------------------------------------
    ---------------------------------------
    | approxkl           | 3.7651822e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 225            |
    | n_updates          | 569            |
    | policy_entropy     | 0.63803226     |
    | policy_loss        | -5.2876072e-05 |
    | serial_timesteps   | 72832          |
    | time_elapsed       | 348            |
    | total_timesteps    | 72832          |
    | value_loss         | 2.8394274e+19  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 1.3560657e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 219           |
    | n_updates          | 570           |
    | policy_entropy     | 0.6414133     |
    | policy_loss        | 3.8899598e-05 |
    | serial_timesteps   | 72960         |
    | time_elapsed       | 349           |
    | total_timesteps    | 72960         |
    | value_loss         | 8.7271514e+18 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 3.9910827e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 212           |
    | n_updates          | 571           |
    | policy_entropy     | 0.63892925    |
    | policy_loss        | 2.1334272e-06 |
    | serial_timesteps   | 73088         |
    | time_elapsed       | 349           |
    | total_timesteps    | 73088         |
    | value_loss         | 6.057154e+17  |
    --------------------------------------
    ------------------------------------------
    | approxkl           | 4.2036405e-08     |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 191               |
    | n_updates          | 572               |
    | policy_entropy     | 0.6406675         |
    | policy_loss        | -1.1354685e-05    |
    | serial_timesteps   | 73216             |
    | time_elapsed       | 350               |
    | total_timesteps    | 73216             |
    | value_loss         | 179347570000000.0 |
    ------------------------------------------
    --------------------------------------
    | approxkl           | 4.32419e-08   |
    | clipfrac           | 0.0           |
    | explained_variance | -1.19e-07     |
    | fps                | 226           |
    | n_updates          | 573           |
    | policy_entropy     | 0.6369406     |
    | policy_loss        | 3.4584664e-05 |
    | serial_timesteps   | 73344         |
    | time_elapsed       | 351           |
    | total_timesteps    | 73344         |
    | value_loss         | 5.748806e+16  |
    --------------------------------------
    -------------------------------------------
    | approxkl           | 3.9300716e-08      |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 226                |
    | n_updates          | 574                |
    | policy_entropy     | 0.6370293          |
    | policy_loss        | -3.4194905e-05     |
    | serial_timesteps   | 73472              |
    | time_elapsed       | 351                |
    | total_timesteps    | 73472              |
    | value_loss         | 1896477400000000.0 |
    -------------------------------------------
    -------------------------------------------
    | approxkl           | 2.7756972e-08      |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 187                |
    | n_updates          | 575                |
    | policy_entropy     | 0.6376436          |
    | policy_loss        | -2.4291687e-05     |
    | serial_timesteps   | 73600              |
    | time_elapsed       | 352                |
    | total_timesteps    | 73600              |
    | value_loss         | 5197566500000000.0 |
    -------------------------------------------
    --------------------------------------
    | approxkl           | 3.6734022e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 206           |
    | n_updates          | 576           |
    | policy_entropy     | 0.6346302     |
    | policy_loss        | 1.0848045e-05 |
    | serial_timesteps   | 73728         |
    | time_elapsed       | 352           |
    | total_timesteps    | 73728         |
    | value_loss         | 8.679161e+16  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.4480756e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 221           |
    | n_updates          | 577           |
    | policy_entropy     | 0.63536656    |
    | policy_loss        | 1.3053068e-05 |
    | serial_timesteps   | 73856         |
    | time_elapsed       | 353           |
    | total_timesteps    | 73856         |
    | value_loss         | 1.3722635e+19 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.9071717e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 189           |
    | n_updates          | 578           |
    | policy_entropy     | 0.64140683    |
    | policy_loss        | 2.6333146e-07 |
    | serial_timesteps   | 73984         |
    | time_elapsed       | 354           |
    | total_timesteps    | 73984         |
    | value_loss         | 7.3283955e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 6.467709e-08  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 189           |
    | n_updates          | 579           |
    | policy_entropy     | 0.63989085    |
    | policy_loss        | 9.035226e-06  |
    | serial_timesteps   | 74112         |
    | time_elapsed       | 354           |
    | total_timesteps    | 74112         |
    | value_loss         | 1.4459968e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 7.7050075e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 188           |
    | n_updates          | 580           |
    | policy_entropy     | 0.64115494    |
    | policy_loss        | 2.2971304e-05 |
    | serial_timesteps   | 74240         |
    | time_elapsed       | 355           |
    | total_timesteps    | 74240         |
    | value_loss         | 8.7106335e+16 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 8.163614e-09  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 220           |
    | n_updates          | 581           |
    | policy_entropy     | 0.63761955    |
    | policy_loss        | 6.146729e-07  |
    | serial_timesteps   | 74368         |
    | time_elapsed       | 356           |
    | total_timesteps    | 74368         |
    | value_loss         | 1.9448493e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.3780447e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 236           |
    | n_updates          | 582           |
    | policy_entropy     | 0.6367395     |
    | policy_loss        | 1.9036233e-06 |
    | serial_timesteps   | 74496         |
    | time_elapsed       | 356           |
    | total_timesteps    | 74496         |
    | value_loss         | 4.0033294e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 2.4186981e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 229           |
    | n_updates          | 583           |
    | policy_entropy     | 0.63880545    |
    | policy_loss        | 1.8858816e-05 |
    | serial_timesteps   | 74624         |
    | time_elapsed       | 357           |
    | total_timesteps    | 74624         |
    | value_loss         | 3.336564e+17  |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.1792329e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 231            |
    | n_updates          | 584            |
    | policy_entropy     | 0.6362415      |
    | policy_loss        | -2.5923597e-05 |
    | serial_timesteps   | 74752          |
    | time_elapsed       | 357            |
    | total_timesteps    | 74752          |
    | value_loss         | 1.6636106e+17  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 2.9693318e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 219           |
    | n_updates          | 585           |
    | policy_entropy     | 0.64046776    |
    | policy_loss        | 3.3761607e-06 |
    | serial_timesteps   | 74880         |
    | time_elapsed       | 358           |
    | total_timesteps    | 74880         |
    | value_loss         | 4.0107944e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 3.1095733e-09 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 202           |
    | n_updates          | 586           |
    | policy_entropy     | 0.6329228     |
    | policy_loss        | 4.666508e-06  |
    | serial_timesteps   | 75008         |
    | time_elapsed       | 358           |
    | total_timesteps    | 75008         |
    | value_loss         | 7.282182e+18  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.9480104e-09 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 194           |
    | n_updates          | 587           |
    | policy_entropy     | 0.6376704     |
    | policy_loss        | 2.3436733e-06 |
    | serial_timesteps   | 75136         |
    | time_elapsed       | 359           |
    | total_timesteps    | 75136         |
    | value_loss         | 7.085254e+18  |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 4.606972e-08   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 194            |
    | n_updates          | 588            |
    | policy_entropy     | 0.6363587      |
    | policy_loss        | -3.6973506e-07 |
    | serial_timesteps   | 75264          |
    | time_elapsed       | 360            |
    | total_timesteps    | 75264          |
    | value_loss         | 1.1222507e+19  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 1.7669149e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 187           |
    | n_updates          | 589           |
    | policy_entropy     | 0.6376105     |
    | policy_loss        | 1.0421383e-05 |
    | serial_timesteps   | 75392         |
    | time_elapsed       | 360           |
    | total_timesteps    | 75392         |
    | value_loss         | 9.477524e+18  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 7.237905e-07  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 191           |
    | n_updates          | 590           |
    | policy_entropy     | 0.63970256    |
    | policy_loss        | 3.799121e-05  |
    | serial_timesteps   | 75520         |
    | time_elapsed       | 361           |
    | total_timesteps    | 75520         |
    | value_loss         | 3.7026123e+18 |
    --------------------------------------
    -------------------------------------------
    | approxkl           | 1.05458284e-07     |
    | clipfrac           | 0.0                |
    | explained_variance | 1.19e-07           |
    | fps                | 231                |
    | n_updates          | 591                |
    | policy_entropy     | 0.63491464         |
    | policy_loss        | 5.5913813e-05      |
    | serial_timesteps   | 75648              |
    | time_elapsed       | 362                |
    | total_timesteps    | 75648              |
    | value_loss         | 1381511300000000.0 |
    -------------------------------------------
    ------------------------------------------
    | approxkl           | 4.326211e-08      |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 237               |
    | n_updates          | 592               |
    | policy_entropy     | 0.63947743        |
    | policy_loss        | -3.363518e-05     |
    | serial_timesteps   | 75776             |
    | time_elapsed       | 362               |
    | total_timesteps    | 75776             |
    | value_loss         | 642452200000000.0 |
    ------------------------------------------
    -------------------------------------------
    | approxkl           | 8.263586e-09       |
    | clipfrac           | 0.0                |
    | explained_variance | 5.96e-08           |
    | fps                | 187                |
    | n_updates          | 593                |
    | policy_entropy     | 0.6338933          |
    | policy_loss        | 3.0389056e-06      |
    | serial_timesteps   | 75904              |
    | time_elapsed       | 363                |
    | total_timesteps    | 75904              |
    | value_loss         | 1762490400000000.0 |
    -------------------------------------------
    -------------------------------------------
    | approxkl           | 2.4227504e-08      |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 206                |
    | n_updates          | 594                |
    | policy_entropy     | 0.6337573          |
    | policy_loss        | 4.565809e-06       |
    | serial_timesteps   | 76032              |
    | time_elapsed       | 364                |
    | total_timesteps    | 76032              |
    | value_loss         | 6727810700000000.0 |
    -------------------------------------------
    --------------------------------------
    | approxkl           | 1.0916564e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 5.96e-08      |
    | fps                | 231           |
    | n_updates          | 595           |
    | policy_entropy     | 0.6348898     |
    | policy_loss        | 6.689341e-06  |
    | serial_timesteps   | 76160         |
    | time_elapsed       | 364           |
    | total_timesteps    | 76160         |
    | value_loss         | 9.794901e+16  |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.458964e-08   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 189            |
    | n_updates          | 596            |
    | policy_entropy     | 0.63546133     |
    | policy_loss        | -2.4593435e-05 |
    | serial_timesteps   | 76288          |
    | time_elapsed       | 365            |
    | total_timesteps    | 76288          |
    | value_loss         | 3.926772e+17   |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 5.6756346e-09 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 199           |
    | n_updates          | 597           |
    | policy_entropy     | 0.6336148     |
    | policy_loss        | 4.8773363e-06 |
    | serial_timesteps   | 76416         |
    | time_elapsed       | 365           |
    | total_timesteps    | 76416         |
    | value_loss         | 6.6831296e+18 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 2.6176656e-09 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 189           |
    | n_updates          | 598           |
    | policy_entropy     | 0.63724977    |
    | policy_loss        | 1.6398262e-06 |
    | serial_timesteps   | 76544         |
    | time_elapsed       | 366           |
    | total_timesteps    | 76544         |
    | value_loss         | 2.5996922e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.9917536e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 213           |
    | n_updates          | 599           |
    | policy_entropy     | 0.63820386    |
    | policy_loss        | 3.2020034e-06 |
    | serial_timesteps   | 76672         |
    | time_elapsed       | 367           |
    | total_timesteps    | 76672         |
    | value_loss         | 3.2793835e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.3737837e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | -1.19e-07     |
    | fps                | 233           |
    | n_updates          | 600           |
    | policy_entropy     | 0.63797516    |
    | policy_loss        | 3.5031699e-06 |
    | serial_timesteps   | 76800         |
    | time_elapsed       | 367           |
    | total_timesteps    | 76800         |
    | value_loss         | 5.370988e+16  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 3.606987e-08  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 220           |
    | n_updates          | 601           |
    | policy_entropy     | 0.6336637     |
    | policy_loss        | -5.152973e-05 |
    | serial_timesteps   | 76928         |
    | time_elapsed       | 368           |
    | total_timesteps    | 76928         |
    | value_loss         | 2.5621562e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.277406e-07  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 224           |
    | n_updates          | 602           |
    | policy_entropy     | 0.63577616    |
    | policy_loss        | 1.4581601e-05 |
    | serial_timesteps   | 77056         |
    | time_elapsed       | 368           |
    | total_timesteps    | 77056         |
    | value_loss         | 3.438889e+17  |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.8104689e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 230            |
    | n_updates          | 603            |
    | policy_entropy     | 0.63681823     |
    | policy_loss        | -1.2898818e-06 |
    | serial_timesteps   | 77184          |
    | time_elapsed       | 369            |
    | total_timesteps    | 77184          |
    | value_loss         | 3.5861712e+17  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 8.1363865e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | -1.19e-07     |
    | fps                | 232           |
    | n_updates          | 604           |
    | policy_entropy     | 0.6373259     |
    | policy_loss        | 8.218223e-06  |
    | serial_timesteps   | 77312         |
    | time_elapsed       | 370           |
    | total_timesteps    | 77312         |
    | value_loss         | 3.36706e+17   |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 2.1386293e-09  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 237            |
    | n_updates          | 605            |
    | policy_entropy     | 0.63775206     |
    | policy_loss        | -1.3294048e-06 |
    | serial_timesteps   | 77440          |
    | time_elapsed       | 370            |
    | total_timesteps    | 77440          |
    | value_loss         | 3.8505917e+18  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 2.527197e-09  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 231           |
    | n_updates          | 606           |
    | policy_entropy     | 0.6337749     |
    | policy_loss        | -6.010523e-06 |
    | serial_timesteps   | 77568         |
    | time_elapsed       | 371           |
    | total_timesteps    | 77568         |
    | value_loss         | 2.4986868e+19 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 3.719909e-08   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 223            |
    | n_updates          | 607            |
    | policy_entropy     | 0.6372005      |
    | policy_loss        | -1.8674647e-05 |
    | serial_timesteps   | 77696          |
    | time_elapsed       | 371            |
    | total_timesteps    | 77696          |
    | value_loss         | 1.3690672e+19  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 1.5885908e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 161           |
    | n_updates          | 608           |
    | policy_entropy     | 0.6360564     |
    | policy_loss        | 1.9627623e-07 |
    | serial_timesteps   | 77824         |
    | time_elapsed       | 372           |
    | total_timesteps    | 77824         |
    | value_loss         | 2.986151e+19  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 3.2098058e-10 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 118           |
    | n_updates          | 609           |
    | policy_entropy     | 0.6374773     |
    | policy_loss        | 2.4816254e-06 |
    | serial_timesteps   | 77952         |
    | time_elapsed       | 373           |
    | total_timesteps    | 77952         |
    | value_loss         | 9.890358e+18  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.4700582e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 118           |
    | n_updates          | 610           |
    | policy_entropy     | 0.639603      |
    | policy_loss        | -9.64338e-06  |
    | serial_timesteps   | 78080         |
    | time_elapsed       | 374           |
    | total_timesteps    | 78080         |
    | value_loss         | 2.5206656e+18 |
    --------------------------------------
    ------------------------------------------
    | approxkl           | 1.5896283e-08     |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 133               |
    | n_updates          | 611               |
    | policy_entropy     | 0.63711           |
    | policy_loss        | -1.47989485e-05   |
    | serial_timesteps   | 78208             |
    | time_elapsed       | 375               |
    | total_timesteps    | 78208             |
    | value_loss         | 346835200000000.0 |
    ------------------------------------------
    -------------------------------------------
    | approxkl           | 2.025612e-09       |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 182                |
    | n_updates          | 612                |
    | policy_entropy     | 0.637503           |
    | policy_loss        | -1.8164283e-06     |
    | serial_timesteps   | 78336              |
    | time_elapsed       | 376                |
    | total_timesteps    | 78336              |
    | value_loss         | 5165980000000000.0 |
    -------------------------------------------
    ---------------------------------------
    | approxkl           | 1.1034841e-09  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 227            |
    | n_updates          | 613            |
    | policy_entropy     | 0.63608724     |
    | policy_loss        | -1.0161893e-06 |
    | serial_timesteps   | 78464          |
    | time_elapsed       | 376            |
    | total_timesteps    | 78464          |
    | value_loss         | 5.0564684e+16  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 6.8139816e-10 |
    | clipfrac           | 0.0           |
    | explained_variance | -1.19e-07     |
    | fps                | 220           |
    | n_updates          | 614           |
    | policy_entropy     | 0.6349537     |
    | policy_loss        | -1.842156e-06 |
    | serial_timesteps   | 78592         |
    | time_elapsed       | 377           |
    | total_timesteps    | 78592         |
    | value_loss         | 1.6476788e+16 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.264015e-08  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 233           |
    | n_updates          | 615           |
    | policy_entropy     | 0.63596386    |
    | policy_loss        | 8.400064e-06  |
    | serial_timesteps   | 78720         |
    | time_elapsed       | 378           |
    | total_timesteps    | 78720         |
    | value_loss         | 2.1962015e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 3.974725e-08   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 228            |
    | n_updates          | 616            |
    | policy_entropy     | 0.6360614      |
    | policy_loss        | -1.8360792e-05 |
    | serial_timesteps   | 78848          |
    | time_elapsed       | 378            |
    | total_timesteps    | 78848          |
    | value_loss         | 1.5556159e+18  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 1.3750762e-08  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 226            |
    | n_updates          | 617            |
    | policy_entropy     | 0.63738513     |
    | policy_loss        | -3.5981648e-06 |
    | serial_timesteps   | 78976          |
    | time_elapsed       | 379            |
    | total_timesteps    | 78976          |
    | value_loss         | 2.1003007e+18  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 2.3867357e-09 |
    | clipfrac           | 0.0           |
    | explained_variance | 1.19e-07      |
    | fps                | 226           |
    | n_updates          | 618           |
    | policy_entropy     | 0.63783634    |
    | policy_loss        | 1.5478581e-06 |
    | serial_timesteps   | 79104         |
    | time_elapsed       | 379           |
    | total_timesteps    | 79104         |
    | value_loss         | 2.0129232e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.9114115e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 227           |
    | n_updates          | 619           |
    | policy_entropy     | 0.63901526    |
    | policy_loss        | -1.080567e-06 |
    | serial_timesteps   | 79232         |
    | time_elapsed       | 380           |
    | total_timesteps    | 79232         |
    | value_loss         | 1.9909055e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 8.171438e-09  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 234           |
    | n_updates          | 620           |
    | policy_entropy     | 0.6397775     |
    | policy_loss        | -5.72484e-06  |
    | serial_timesteps   | 79360         |
    | time_elapsed       | 380           |
    | total_timesteps    | 79360         |
    | value_loss         | 1.1887755e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 5.8494706e-08  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 224            |
    | n_updates          | 621            |
    | policy_entropy     | 0.63579446     |
    | policy_loss        | -3.1338306e-05 |
    | serial_timesteps   | 79488          |
    | time_elapsed       | 381            |
    | total_timesteps    | 79488          |
    | value_loss         | 1.1062419e+18  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 8.3083975e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 225           |
    | n_updates          | 622           |
    | policy_entropy     | 0.6380542     |
    | policy_loss        | 1.6935519e-05 |
    | serial_timesteps   | 79616         |
    | time_elapsed       | 382           |
    | total_timesteps    | 79616         |
    | value_loss         | 2.0367924e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 2.4753259e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 220           |
    | n_updates          | 623           |
    | policy_entropy     | 0.6366323     |
    | policy_loss        | 1.7021317e-05 |
    | serial_timesteps   | 79744         |
    | time_elapsed       | 382           |
    | total_timesteps    | 79744         |
    | value_loss         | 1.8284088e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 8.424287e-09  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 223           |
    | n_updates          | 624           |
    | policy_entropy     | 0.6385946     |
    | policy_loss        | 4.0462473e-06 |
    | serial_timesteps   | 79872         |
    | time_elapsed       | 383           |
    | total_timesteps    | 79872         |
    | value_loss         | 2.7060486e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 2.122753e-08   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 185            |
    | n_updates          | 625            |
    | policy_entropy     | 0.6374618      |
    | policy_loss        | -3.2848446e-05 |
    | serial_timesteps   | 80000          |
    | time_elapsed       | 383            |
    | total_timesteps    | 80000          |
    | value_loss         | 5.002867e+18   |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 1.9719135e-08  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 185            |
    | n_updates          | 626            |
    | policy_entropy     | 0.635828       |
    | policy_loss        | -2.0211446e-05 |
    | serial_timesteps   | 80128          |
    | time_elapsed       | 384            |
    | total_timesteps    | 80128          |
    | value_loss         | 5.505682e+19   |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 6.756155e-09  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 189           |
    | n_updates          | 627           |
    | policy_entropy     | 0.6389917     |
    | policy_loss        | 6.3652406e-06 |
    | serial_timesteps   | 80256         |
    | time_elapsed       | 385           |
    | total_timesteps    | 80256         |
    | value_loss         | 6.2716286e+18 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.6996711e-10  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 219            |
    | n_updates          | 628            |
    | policy_entropy     | 0.6365985      |
    | policy_loss        | -2.1026935e-06 |
    | serial_timesteps   | 80384          |
    | time_elapsed       | 385            |
    | total_timesteps    | 80384          |
    | value_loss         | 6.766885e+18   |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 4.2900866e-10  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 226            |
    | n_updates          | 629            |
    | policy_entropy     | 0.6400918      |
    | policy_loss        | -1.8579885e-06 |
    | serial_timesteps   | 80512          |
    | time_elapsed       | 386            |
    | total_timesteps    | 80512          |
    | value_loss         | 7.9561794e+18  |
    ---------------------------------------
    -------------------------------------
    | approxkl           | 4.912753e-10 |
    | clipfrac           | 0.0          |
    | explained_variance | 0            |
    | fps                | 228          |
    | n_updates          | 630          |
    | policy_entropy     | 0.63828254   |
    | policy_loss        | -3.90457e-07 |
    | serial_timesteps   | 80640        |
    | time_elapsed       | 387          |
    | total_timesteps    | 80640        |
    | value_loss         | 7.265396e+17 |
    -------------------------------------
    ------------------------------------------
    | approxkl           | 1.8398262e-09     |
    | clipfrac           | 0.0               |
    | explained_variance | 1.19e-07          |
    | fps                | 237               |
    | n_updates          | 631               |
    | policy_entropy     | 0.64044905        |
    | policy_loss        | -6.2200706e-06    |
    | serial_timesteps   | 80768             |
    | time_elapsed       | 387               |
    | total_timesteps    | 80768             |
    | value_loss         | 351355700000000.0 |
    ------------------------------------------
    --------------------------------------
    | approxkl           | 1.1490365e-09 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 226           |
    | n_updates          | 632           |
    | policy_entropy     | 0.6370522     |
    | policy_loss        | 8.5448846e-08 |
    | serial_timesteps   | 80896         |
    | time_elapsed       | 388           |
    | total_timesteps    | 80896         |
    | value_loss         | 5.3172107e+16 |
    --------------------------------------
    -------------------------------------------
    | approxkl           | 1.7833018e-10      |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 208                |
    | n_updates          | 633                |
    | policy_entropy     | 0.63726616         |
    | policy_loss        | -4.3818727e-07     |
    | serial_timesteps   | 81024              |
    | time_elapsed       | 388                |
    | total_timesteps    | 81024              |
    | value_loss         | 1223138100000000.0 |
    -------------------------------------------
    --------------------------------------
    | approxkl           | 3.896593e-11  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 179           |
    | n_updates          | 634           |
    | policy_entropy     | 0.638168      |
    | policy_loss        | 5.0477684e-07 |
    | serial_timesteps   | 81152         |
    | time_elapsed       | 389           |
    | total_timesteps    | 81152         |
    | value_loss         | 1.735128e+16  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 4.0104184e-11 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 188           |
    | n_updates          | 635           |
    | policy_entropy     | 0.63618       |
    | policy_loss        | -5.03147e-07  |
    | serial_timesteps   | 81280         |
    | time_elapsed       | 390           |
    | total_timesteps    | 81280         |
    | value_loss         | 3.211017e+17  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 3.1939865e-10 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 213           |
    | n_updates          | 636           |
    | policy_entropy     | 0.63689446    |
    | policy_loss        | 9.313226e-09  |
    | serial_timesteps   | 81408         |
    | time_elapsed       | 390           |
    | total_timesteps    | 81408         |
    | value_loss         | 5.0903727e+18 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 3.4683887e-09 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 229           |
    | n_updates          | 637           |
    | policy_entropy     | 0.6397166     |
    | policy_loss        | 4.6382193e-06 |
    | serial_timesteps   | 81536         |
    | time_elapsed       | 391           |
    | total_timesteps    | 81536         |
    | value_loss         | 5.0656806e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 2.1241728e-09 |
    | clipfrac           | 0.0           |
    | explained_variance | -1.19e-07     |
    | fps                | 236           |
    | n_updates          | 638           |
    | policy_entropy     | 0.639473      |
    | policy_loss        | 4.7353096e-06 |
    | serial_timesteps   | 81664         |
    | time_elapsed       | 391           |
    | total_timesteps    | 81664         |
    | value_loss         | 1.2257512e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.1295242e-10 |
    | clipfrac           | 0.0           |
    | explained_variance | -1.19e-07     |
    | fps                | 232           |
    | n_updates          | 639           |
    | policy_entropy     | 0.6398065     |
    | policy_loss        | 3.096182e-06  |
    | serial_timesteps   | 81792         |
    | time_elapsed       | 392           |
    | total_timesteps    | 81792         |
    | value_loss         | 9.898666e+16  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 9.943126e-10  |
    | clipfrac           | 0.0           |
    | explained_variance | -2.38e-07     |
    | fps                | 231           |
    | n_updates          | 640           |
    | policy_entropy     | 0.6386418     |
    | policy_loss        | 1.7959392e-06 |
    | serial_timesteps   | 81920         |
    | time_elapsed       | 393           |
    | total_timesteps    | 81920         |
    | value_loss         | 6.5645064e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 6.4561663e-09  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 235            |
    | n_updates          | 641            |
    | policy_entropy     | 0.63753796     |
    | policy_loss        | -2.6114285e-06 |
    | serial_timesteps   | 82048          |
    | time_elapsed       | 393            |
    | total_timesteps    | 82048          |
    | value_loss         | 3.7086967e+17  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 5.2522435e-09  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 193            |
    | n_updates          | 642            |
    | policy_entropy     | 0.638872       |
    | policy_loss        | -1.7613638e-06 |
    | serial_timesteps   | 82176          |
    | time_elapsed       | 394            |
    | total_timesteps    | 82176          |
    | value_loss         | 9.4188736e+17  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 3.835872e-09  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 196           |
    | n_updates          | 643           |
    | policy_entropy     | 0.6369528     |
    | policy_loss        | 3.762776e-06  |
    | serial_timesteps   | 82304         |
    | time_elapsed       | 394           |
    | total_timesteps    | 82304         |
    | value_loss         | 2.2973321e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 3.9933816e-09 |
    | clipfrac           | 0.0           |
    | explained_variance | 1.19e-07      |
    | fps                | 191           |
    | n_updates          | 644           |
    | policy_entropy     | 0.641234      |
    | policy_loss        | 3.880821e-06  |
    | serial_timesteps   | 82432         |
    | time_elapsed       | 395           |
    | total_timesteps    | 82432         |
    | value_loss         | 9.916208e+17  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.836059e-09  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 195           |
    | n_updates          | 645           |
    | policy_entropy     | 0.6356697     |
    | policy_loss        | 5.8226287e-06 |
    | serial_timesteps   | 82560         |
    | time_elapsed       | 396           |
    | total_timesteps    | 82560         |
    | value_loss         | 8.5593253e+18 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 6.2999534e-09 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 213           |
    | n_updates          | 646           |
    | policy_entropy     | 0.6381097     |
    | policy_loss        | 4.640082e-06  |
    | serial_timesteps   | 82688         |
    | time_elapsed       | 396           |
    | total_timesteps    | 82688         |
    | value_loss         | 9.0035995e+18 |
    --------------------------------------
    -------------------------------------
    | approxkl           | 3.046163e-09 |
    | clipfrac           | 0.0          |
    | explained_variance | 0            |
    | fps                | 228          |
    | n_updates          | 647          |
    | policy_entropy     | 0.63810694   |
    | policy_loss        | 3.23751e-07  |
    | serial_timesteps   | 82816        |
    | time_elapsed       | 397          |
    | total_timesteps    | 82816        |
    | value_loss         | 9.233825e+18 |
    -------------------------------------
    --------------------------------------
    | approxkl           | 3.1037446e-09 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 245           |
    | n_updates          | 648           |
    | policy_entropy     | 0.6384716     |
    | policy_loss        | 1.991284e-06  |
    | serial_timesteps   | 82944         |
    | time_elapsed       | 397           |
    | total_timesteps    | 82944         |
    | value_loss         | 6.5550706e+18 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 2.211908e-09   |
    | clipfrac           | 0.0            |
    | explained_variance | 5.96e-08       |
    | fps                | 224            |
    | n_updates          | 649            |
    | policy_entropy     | 0.6406613      |
    | policy_loss        | -5.4424163e-07 |
    | serial_timesteps   | 83072          |
    | time_elapsed       | 398            |
    | total_timesteps    | 83072          |
    | value_loss         | 2.564568e+18   |
    ---------------------------------------
    -------------------------------------------
    | approxkl           | 3.41398e-09        |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 229                |
    | n_updates          | 650                |
    | policy_entropy     | 0.63789344         |
    | policy_loss        | -1.4480902e-06     |
    | serial_timesteps   | 83200              |
    | time_elapsed       | 399                |
    | total_timesteps    | 83200              |
    | value_loss         | 1046505150000000.0 |
    -------------------------------------------
    ------------------------------------------
    | approxkl           | 6.813157e-09      |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 227               |
    | n_updates          | 651               |
    | policy_entropy     | 0.6421479         |
    | policy_loss        | 1.112977e-05      |
    | serial_timesteps   | 83328             |
    | time_elapsed       | 399               |
    | total_timesteps    | 83328             |
    | value_loss         | 647451300000000.0 |
    ------------------------------------------
    ------------------------------------------
    | approxkl           | 4.5752486e-09     |
    | clipfrac           | 0.0               |
    | explained_variance | -1.19e-07         |
    | fps                | 205               |
    | n_updates          | 652               |
    | policy_entropy     | 0.6369345         |
    | policy_loss        | -9.685988e-06     |
    | serial_timesteps   | 83456             |
    | time_elapsed       | 400               |
    | total_timesteps    | 83456             |
    | value_loss         | 100366510000000.0 |
    ------------------------------------------
    -------------------------------------------
    | approxkl           | 3.064891e-09       |
    | clipfrac           | 0.0                |
    | explained_variance | 1.19e-07           |
    | fps                | 238                |
    | n_updates          | 653                |
    | policy_entropy     | 0.63699543         |
    | policy_loss        | 1.01363985e-05     |
    | serial_timesteps   | 83584              |
    | time_elapsed       | 400                |
    | total_timesteps    | 83584              |
    | value_loss         | 4877569000000000.0 |
    -------------------------------------------
    --------------------------------------
    | approxkl           | 9.318111e-10  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 223           |
    | n_updates          | 654           |
    | policy_entropy     | 0.637967      |
    | policy_loss        | 6.9215894e-06 |
    | serial_timesteps   | 83712         |
    | time_elapsed       | 401           |
    | total_timesteps    | 83712         |
    | value_loss         | 2.7705988e+16 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 5.888799e-11   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 214            |
    | n_updates          | 655            |
    | policy_entropy     | 0.63873875     |
    | policy_loss        | -3.6368147e-07 |
    | serial_timesteps   | 83840          |
    | time_elapsed       | 401            |
    | total_timesteps    | 83840          |
    | value_loss         | 4.229809e+17   |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 6.2614613e-10 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 197           |
    | n_updates          | 656           |
    | policy_entropy     | 0.6369828     |
    | policy_loss        | -6.7777e-07   |
    | serial_timesteps   | 83968         |
    | time_elapsed       | 402           |
    | total_timesteps    | 83968         |
    | value_loss         | 2.0365128e+19 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.2505174e-09  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 220            |
    | n_updates          | 657            |
    | policy_entropy     | 0.6399788      |
    | policy_loss        | -1.0565855e-06 |
    | serial_timesteps   | 84096          |
    | time_elapsed       | 403            |
    | total_timesteps    | 84096          |
    | value_loss         | 1.733895e+17   |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 1.642987e-09  |
    | clipfrac           | 0.0           |
    | explained_variance | 5.96e-08      |
    | fps                | 228           |
    | n_updates          | 658           |
    | policy_entropy     | 0.6412932     |
    | policy_loss        | 4.860107e-06  |
    | serial_timesteps   | 84224         |
    | time_elapsed       | 403           |
    | total_timesteps    | 84224         |
    | value_loss         | 2.8748558e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.4741678e-09  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 229            |
    | n_updates          | 659            |
    | policy_entropy     | 0.64122474     |
    | policy_loss        | -3.7980499e-06 |
    | serial_timesteps   | 84352          |
    | time_elapsed       | 404            |
    | total_timesteps    | 84352          |
    | value_loss         | 1.72505e+16    |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 7.937931e-10   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 232            |
    | n_updates          | 660            |
    | policy_entropy     | 0.6371885      |
    | policy_loss        | -1.4831312e-06 |
    | serial_timesteps   | 84480          |
    | time_elapsed       | 404            |
    | total_timesteps    | 84480          |
    | value_loss         | 5.6590235e+17  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 4.8574067e-10 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 228           |
    | n_updates          | 661           |
    | policy_entropy     | 0.6389792     |
    | policy_loss        | 2.4398323e-06 |
    | serial_timesteps   | 84608         |
    | time_elapsed       | 405           |
    | total_timesteps    | 84608         |
    | value_loss         | 1.9040549e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.2307289e-10 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 237           |
    | n_updates          | 662           |
    | policy_entropy     | 0.6395316     |
    | policy_loss        | 9.634532e-07  |
    | serial_timesteps   | 84736         |
    | time_elapsed       | 405           |
    | total_timesteps    | 84736         |
    | value_loss         | 6.60579e+17   |
    --------------------------------------
    --------------------------------------
    | approxkl           | 9.628456e-10  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 233           |
    | n_updates          | 663           |
    | policy_entropy     | 0.63978803    |
    | policy_loss        | 4.007714e-06  |
    | serial_timesteps   | 84864         |
    | time_elapsed       | 406           |
    | total_timesteps    | 84864         |
    | value_loss         | 3.0004394e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 8.3825213e-10  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 236            |
    | n_updates          | 664            |
    | policy_entropy     | 0.64014643     |
    | policy_loss        | -1.6586855e-06 |
    | serial_timesteps   | 84992          |
    | time_elapsed       | 407            |
    | total_timesteps    | 84992          |
    | value_loss         | 5.828921e+18   |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 1.018942e-09   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 226            |
    | n_updates          | 665            |
    | policy_entropy     | 0.6361803      |
    | policy_loss        | -2.5205081e-06 |
    | serial_timesteps   | 85120          |
    | time_elapsed       | 407            |
    | total_timesteps    | 85120          |
    | value_loss         | 3.4362769e+19  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 2.0238697e-09 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 232           |
    | n_updates          | 666           |
    | policy_entropy     | 0.6392661     |
    | policy_loss        | 5.9797894e-06 |
    | serial_timesteps   | 85248         |
    | time_elapsed       | 408           |
    | total_timesteps    | 85248         |
    | value_loss         | 3.6772639e+18 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 7.395381e-09  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 233           |
    | n_updates          | 667           |
    | policy_entropy     | 0.6380811     |
    | policy_loss        | -4.733214e-06 |
    | serial_timesteps   | 85376         |
    | time_elapsed       | 408           |
    | total_timesteps    | 85376         |
    | value_loss         | 3.1916496e+19 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 3.8501566e-09 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 235           |
    | n_updates          | 668           |
    | policy_entropy     | 0.6392828     |
    | policy_loss        | -5.610753e-06 |
    | serial_timesteps   | 85504         |
    | time_elapsed       | 409           |
    | total_timesteps    | 85504         |
    | value_loss         | 3.9353596e+18 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.9807918e-09  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 229            |
    | n_updates          | 669            |
    | policy_entropy     | 0.6414768      |
    | policy_loss        | -2.3860484e-06 |
    | serial_timesteps   | 85632          |
    | time_elapsed       | 409            |
    | total_timesteps    | 85632          |
    | value_loss         | 1.6292835e+18  |
    ---------------------------------------
    ------------------------------------------
    | approxkl           | 5.481642e-08      |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 214               |
    | n_updates          | 670               |
    | policy_entropy     | 0.63900733        |
    | policy_loss        | -4.2069005e-06    |
    | serial_timesteps   | 85760             |
    | time_elapsed       | 410               |
    | total_timesteps    | 85760             |
    | value_loss         | 542596840000000.0 |
    ------------------------------------------
    -------------------------------------------
    | approxkl           | 2.208555e-07       |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 230                |
    | n_updates          | 671                |
    | policy_entropy     | 0.6397513          |
    | policy_loss        | -6.4405613e-06     |
    | serial_timesteps   | 85888              |
    | time_elapsed       | 411                |
    | total_timesteps    | 85888              |
    | value_loss         | 3045945200000000.0 |
    -------------------------------------------
    ------------------------------------------
    | approxkl           | 1.1769515e-07     |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 220               |
    | n_updates          | 672               |
    | policy_entropy     | 0.6387958         |
    | policy_loss        | 3.535766e-05      |
    | serial_timesteps   | 86016             |
    | time_elapsed       | 411               |
    | total_timesteps    | 86016             |
    | value_loss         | 312683200000000.0 |
    ------------------------------------------
    -------------------------------------------
    | approxkl           | 4.0255944e-08      |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 239                |
    | n_updates          | 673                |
    | policy_entropy     | 0.63785934         |
    | policy_loss        | -2.6749913e-06     |
    | serial_timesteps   | 86144              |
    | time_elapsed       | 412                |
    | total_timesteps    | 86144              |
    | value_loss         | 7554502000000000.0 |
    -------------------------------------------
    --------------------------------------
    | approxkl           | 5.257726e-08  |
    | clipfrac           | 0.0           |
    | explained_variance | -1.19e-07     |
    | fps                | 228           |
    | n_updates          | 674           |
    | policy_entropy     | 0.6385857     |
    | policy_loss        | 2.0469306e-06 |
    | serial_timesteps   | 86272         |
    | time_elapsed       | 412           |
    | total_timesteps    | 86272         |
    | value_loss         | 1.6716879e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 2.2436787e-08  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 241            |
    | n_updates          | 675            |
    | policy_entropy     | 0.6378453      |
    | policy_loss        | -1.0166201e-05 |
    | serial_timesteps   | 86400          |
    | time_elapsed       | 413            |
    | total_timesteps    | 86400          |
    | value_loss         | 6.2320704e+18  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 5.733033e-08   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 230            |
    | n_updates          | 676            |
    | policy_entropy     | 0.639627       |
    | policy_loss        | -2.0588865e-05 |
    | serial_timesteps   | 86528          |
    | time_elapsed       | 413            |
    | total_timesteps    | 86528          |
    | value_loss         | 1.412121e+18   |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 1.7761165e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 235            |
    | n_updates          | 677            |
    | policy_entropy     | 0.6409601      |
    | policy_loss        | -1.7856248e-05 |
    | serial_timesteps   | 86656          |
    | time_elapsed       | 414            |
    | total_timesteps    | 86656          |
    | value_loss         | 1.9177228e+17  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 3.067321e-07  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 233           |
    | n_updates          | 678           |
    | policy_entropy     | 0.6429118     |
    | policy_loss        | 1.5546917e-05 |
    | serial_timesteps   | 86784         |
    | time_elapsed       | 414           |
    | total_timesteps    | 86784         |
    | value_loss         | 1.742584e+17  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.3486962e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | -1.19e-07     |
    | fps                | 228           |
    | n_updates          | 679           |
    | policy_entropy     | 0.6434496     |
    | policy_loss        | 5.4184115e-05 |
    | serial_timesteps   | 86912         |
    | time_elapsed       | 415           |
    | total_timesteps    | 86912         |
    | value_loss         | 1.9034086e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 6.1726155e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 233           |
    | n_updates          | 680           |
    | policy_entropy     | 0.6396078     |
    | policy_loss        | 2.1020416e-05 |
    | serial_timesteps   | 87040         |
    | time_elapsed       | 416           |
    | total_timesteps    | 87040         |
    | value_loss         | 8.3468264e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 9.6495086e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 244           |
    | n_updates          | 681           |
    | policy_entropy     | 0.6427069     |
    | policy_loss        | 1.661852e-05  |
    | serial_timesteps   | 87168         |
    | time_elapsed       | 416           |
    | total_timesteps    | 87168         |
    | value_loss         | 4.005477e+17  |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.392053e-07   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 236            |
    | n_updates          | 682            |
    | policy_entropy     | 0.64100254     |
    | policy_loss        | -4.7818758e-05 |
    | serial_timesteps   | 87296          |
    | time_elapsed       | 417            |
    | total_timesteps    | 87296          |
    | value_loss         | 6.9435e+17     |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 7.656684e-08  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 238           |
    | n_updates          | 683           |
    | policy_entropy     | 0.6434457     |
    | policy_loss        | 6.4393505e-05 |
    | serial_timesteps   | 87424         |
    | time_elapsed       | 417           |
    | total_timesteps    | 87424         |
    | value_loss         | 1.2389005e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.2171149e-09  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 223            |
    | n_updates          | 684            |
    | policy_entropy     | 0.64106536     |
    | policy_loss        | -1.8405262e-06 |
    | serial_timesteps   | 87552          |
    | time_elapsed       | 418            |
    | total_timesteps    | 87552          |
    | value_loss         | 1.5289886e+19  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 5.728839e-10   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 192            |
    | n_updates          | 685            |
    | policy_entropy     | 0.6400672      |
    | policy_loss        | -3.0943193e-07 |
    | serial_timesteps   | 87680          |
    | time_elapsed       | 418            |
    | total_timesteps    | 87680          |
    | value_loss         | 2.2538016e+19  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 2.339182e-08   |
    | clipfrac           | 0.0            |
    | explained_variance | 5.96e-08       |
    | fps                | 197            |
    | n_updates          | 686            |
    | policy_entropy     | 0.64330846     |
    | policy_loss        | -6.3043553e-06 |
    | serial_timesteps   | 87808          |
    | time_elapsed       | 419            |
    | total_timesteps    | 87808          |
    | value_loss         | 8.633044e+18   |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 3.5630862e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 191           |
    | n_updates          | 687           |
    | policy_entropy     | 0.6413429     |
    | policy_loss        | 1.7338432e-05 |
    | serial_timesteps   | 87936         |
    | time_elapsed       | 420           |
    | total_timesteps    | 87936         |
    | value_loss         | 1.269622e+19  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 7.4692343e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 190           |
    | n_updates          | 688           |
    | policy_entropy     | 0.6453817     |
    | policy_loss        | 1.3126526e-05 |
    | serial_timesteps   | 88064         |
    | time_elapsed       | 420           |
    | total_timesteps    | 88064         |
    | value_loss         | 5.2923585e+18 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 2.6175233e-06  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 221            |
    | n_updates          | 689            |
    | policy_entropy     | 0.64447784     |
    | policy_loss        | -1.4977995e-05 |
    | serial_timesteps   | 88192          |
    | time_elapsed       | 421            |
    | total_timesteps    | 88192          |
    | value_loss         | 1.4462541e+17  |
    ---------------------------------------
    ------------------------------------------
    | approxkl           | 1.150024e-06      |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 229               |
    | n_updates          | 690               |
    | policy_entropy     | 0.6479549         |
    | policy_loss        | -3.8170023e-05    |
    | serial_timesteps   | 88320             |
    | time_elapsed       | 422               |
    | total_timesteps    | 88320             |
    | value_loss         | 400202230000000.0 |
    ------------------------------------------
    --------------------------------------
    | approxkl           | 3.9163947e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | -1.19e-07     |
    | fps                | 234           |
    | n_updates          | 691           |
    | policy_entropy     | 0.6458676     |
    | policy_loss        | 5.736365e-07  |
    | serial_timesteps   | 88448         |
    | time_elapsed       | 422           |
    | total_timesteps    | 88448         |
    | value_loss         | 4.7504078e+16 |
    --------------------------------------
    -------------------------------------------
    | approxkl           | 6.4797064e-08      |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 236                |
    | n_updates          | 692                |
    | policy_entropy     | 0.64662945         |
    | policy_loss        | -2.4965964e-05     |
    | serial_timesteps   | 88576              |
    | time_elapsed       | 423                |
    | total_timesteps    | 88576              |
    | value_loss         | 2456450200000000.0 |
    -------------------------------------------
    -------------------------------------
    | approxkl           | 9.053954e-09 |
    | clipfrac           | 0.0          |
    | explained_variance | -1.19e-07    |
    | fps                | 232          |
    | n_updates          | 693          |
    | policy_entropy     | 0.6472865    |
    | policy_loss        | 1.07917e-05  |
    | serial_timesteps   | 88704        |
    | time_elapsed       | 423          |
    | total_timesteps    | 88704        |
    | value_loss         | 1.722463e+17 |
    -------------------------------------
    ---------------------------------------
    | approxkl           | 3.310923e-08   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 234            |
    | n_updates          | 694            |
    | policy_entropy     | 0.6453013      |
    | policy_loss        | -2.8840266e-05 |
    | serial_timesteps   | 88832          |
    | time_elapsed       | 424            |
    | total_timesteps    | 88832          |
    | value_loss         | 1.1736495e+18  |
    ---------------------------------------
    -------------------------------------
    | approxkl           | 8.811935e-09 |
    | clipfrac           | 0.0          |
    | explained_variance | 0            |
    | fps                | 191          |
    | n_updates          | 695          |
    | policy_entropy     | 0.64580655   |
    | policy_loss        | 7.119961e-07 |
    | serial_timesteps   | 88960        |
    | time_elapsed       | 424          |
    | total_timesteps    | 88960        |
    | value_loss         | 4.149069e+18 |
    -------------------------------------
    ---------------------------------------
    | approxkl           | 2.2876463e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 210            |
    | n_updates          | 696            |
    | policy_entropy     | 0.64727324     |
    | policy_loss        | -3.5879435e-05 |
    | serial_timesteps   | 89088          |
    | time_elapsed       | 425            |
    | total_timesteps    | 89088          |
    | value_loss         | 5.4667807e+17  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 3.2289185e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 233            |
    | n_updates          | 697            |
    | policy_entropy     | 0.64681065     |
    | policy_loss        | 2.0936597e-05  |
    | serial_timesteps   | 89216          |
    | time_elapsed       | 426            |
    | total_timesteps    | 89216          |
    | value_loss         | 1.28405856e+17 |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 4.3285726e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 244           |
    | n_updates          | 698           |
    | policy_entropy     | 0.64605963    |
    | policy_loss        | 7.9782214e-05 |
    | serial_timesteps   | 89344         |
    | time_elapsed       | 426           |
    | total_timesteps    | 89344         |
    | value_loss         | 2.6433093e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 2.1938115e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 233           |
    | n_updates          | 699           |
    | policy_entropy     | 0.6452141     |
    | policy_loss        | -6.623147e-05 |
    | serial_timesteps   | 89472         |
    | time_elapsed       | 427           |
    | total_timesteps    | 89472         |
    | value_loss         | 1.8518932e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 9.943794e-08   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 247            |
    | n_updates          | 700            |
    | policy_entropy     | 0.64369196     |
    | policy_loss        | 1.47117535e-05 |
    | serial_timesteps   | 89600          |
    | time_elapsed       | 427            |
    | total_timesteps    | 89600          |
    | value_loss         | 5.431668e+17   |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 7.733745e-08  |
    | clipfrac           | 0.0           |
    | explained_variance | 5.96e-08      |
    | fps                | 232           |
    | n_updates          | 701           |
    | policy_entropy     | 0.64522815    |
    | policy_loss        | 3.603543e-05  |
    | serial_timesteps   | 89728         |
    | time_elapsed       | 428           |
    | total_timesteps    | 89728         |
    | value_loss         | 1.0691807e+18 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 4.599527e-08   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 239            |
    | n_updates          | 702            |
    | policy_entropy     | 0.6434685      |
    | policy_loss        | 1.09921675e-05 |
    | serial_timesteps   | 89856          |
    | time_elapsed       | 428            |
    | total_timesteps    | 89856          |
    | value_loss         | 3.1651854e+17  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 3.344628e-08   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 230            |
    | n_updates          | 703            |
    | policy_entropy     | 0.6475453      |
    | policy_loss        | -3.4207478e-06 |
    | serial_timesteps   | 89984          |
    | time_elapsed       | 429            |
    | total_timesteps    | 89984          |
    | value_loss         | 1.9203197e+17  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 6.3463985e-09 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 193           |
    | n_updates          | 704           |
    | policy_entropy     | 0.6413578     |
    | policy_loss        | 3.0510128e-06 |
    | serial_timesteps   | 90112         |
    | time_elapsed       | 429           |
    | total_timesteps    | 90112         |
    | value_loss         | 2.229375e+19  |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 3.970692e-09   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 183            |
    | n_updates          | 705            |
    | policy_entropy     | 0.6438395      |
    | policy_loss        | -1.3427343e-06 |
    | serial_timesteps   | 90240          |
    | time_elapsed       | 430            |
    | total_timesteps    | 90240          |
    | value_loss         | 2.3379408e+19  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 2.535703e-08  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 190           |
    | n_updates          | 706           |
    | policy_entropy     | 0.6451029     |
    | policy_loss        | 1.6946578e-05 |
    | serial_timesteps   | 90368         |
    | time_elapsed       | 431           |
    | total_timesteps    | 90368         |
    | value_loss         | 9.723311e+18  |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 4.4837456e-08  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 202            |
    | n_updates          | 707            |
    | policy_entropy     | 0.64422446     |
    | policy_loss        | -1.8206658e-05 |
    | serial_timesteps   | 90496          |
    | time_elapsed       | 431            |
    | total_timesteps    | 90496          |
    | value_loss         | 1.6233657e+19  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 2.617884e-07   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 202            |
    | n_updates          | 708            |
    | policy_entropy     | 0.64603686     |
    | policy_loss        | -0.00011058268 |
    | serial_timesteps   | 90624          |
    | time_elapsed       | 432            |
    | total_timesteps    | 90624          |
    | value_loss         | 9.985626e+18   |
    ---------------------------------------
    ------------------------------------------
    | approxkl           | 1.8564936e-07     |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 240               |
    | n_updates          | 709               |
    | policy_entropy     | 0.64544547        |
    | policy_loss        | -2.0458945e-05    |
    | serial_timesteps   | 90752             |
    | time_elapsed       | 433               |
    | total_timesteps    | 90752             |
    | value_loss         | 454971620000000.0 |
    ------------------------------------------
    -------------------------------------------
    | approxkl           | 3.3831785e-08      |
    | clipfrac           | 0.0                |
    | explained_variance | -1.19e-07          |
    | fps                | 242                |
    | n_updates          | 710                |
    | policy_entropy     | 0.6501223          |
    | policy_loss        | 8.4750354e-07      |
    | serial_timesteps   | 90880              |
    | time_elapsed       | 433                |
    | total_timesteps    | 90880              |
    | value_loss         | 1781254000000000.0 |
    -------------------------------------------
    -------------------------------------------
    | approxkl           | 4.258054e-07       |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 243                |
    | n_updates          | 711                |
    | policy_entropy     | 0.64527714         |
    | policy_loss        | 1.5072059e-05      |
    | serial_timesteps   | 91008              |
    | time_elapsed       | 434                |
    | total_timesteps    | 91008              |
    | value_loss         | 2439666500000000.0 |
    -------------------------------------------
    -------------------------------------------
    | approxkl           | 1.4200591e-06      |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 225                |
    | n_updates          | 712                |
    | policy_entropy     | 0.6453202          |
    | policy_loss        | 1.8598512e-05      |
    | serial_timesteps   | 91136              |
    | time_elapsed       | 434                |
    | total_timesteps    | 91136              |
    | value_loss         | 4543951400000000.0 |
    -------------------------------------------
    ---------------------------------------
    | approxkl           | 4.8643307e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 198            |
    | n_updates          | 713            |
    | policy_entropy     | 0.6439969      |
    | policy_loss        | -1.5749363e-05 |
    | serial_timesteps   | 91264          |
    | time_elapsed       | 435            |
    | total_timesteps    | 91264          |
    | value_loss         | 2.2322732e+17  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 2.9477482e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 244            |
    | n_updates          | 714            |
    | policy_entropy     | 0.64388776     |
    | policy_loss        | -1.1899043e-05 |
    | serial_timesteps   | 91392          |
    | time_elapsed       | 435            |
    | total_timesteps    | 91392          |
    | value_loss         | 5.2386458e+17  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 8.9317314e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 246            |
    | n_updates          | 715            |
    | policy_entropy     | 0.6404562      |
    | policy_loss        | -3.6901794e-05 |
    | serial_timesteps   | 91520          |
    | time_elapsed       | 436            |
    | total_timesteps    | 91520          |
    | value_loss         | 3.2087246e+18  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 3.6759567e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 203           |
    | n_updates          | 716           |
    | policy_entropy     | 0.64230955    |
    | policy_loss        | 3.4683617e-05 |
    | serial_timesteps   | 91648         |
    | time_elapsed       | 437           |
    | total_timesteps    | 91648         |
    | value_loss         | 3.866649e+17  |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 6.391379e-09   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 202            |
    | n_updates          | 717            |
    | policy_entropy     | 0.6443294      |
    | policy_loss        | -5.1740208e-06 |
    | serial_timesteps   | 91776          |
    | time_elapsed       | 437            |
    | total_timesteps    | 91776          |
    | value_loss         | 2.4363063e+17  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 3.4835081e-09 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 200           |
    | n_updates          | 718           |
    | policy_entropy     | 0.6429729     |
    | policy_loss        | 1.1683442e-06 |
    | serial_timesteps   | 91904         |
    | time_elapsed       | 438           |
    | total_timesteps    | 91904         |
    | value_loss         | 5.689117e+16  |
    --------------------------------------
    -------------------------------------
    | approxkl           | 1.892429e-07 |
    | clipfrac           | 0.0          |
    | explained_variance | 0            |
    | fps                | 228          |
    | n_updates          | 719          |
    | policy_entropy     | 0.63985455   |
    | policy_loss        | 2.63385e-05  |
    | serial_timesteps   | 92032        |
    | time_elapsed       | 438          |
    | total_timesteps    | 92032        |
    | value_loss         | 4.301401e+17 |
    -------------------------------------
    --------------------------------------
    | approxkl           | 3.391293e-07  |
    | clipfrac           | 0.0           |
    | explained_variance | -1.19e-07     |
    | fps                | 243           |
    | n_updates          | 720           |
    | policy_entropy     | 0.64084756    |
    | policy_loss        | 2.6871101e-05 |
    | serial_timesteps   | 92160         |
    | time_elapsed       | 439           |
    | total_timesteps    | 92160         |
    | value_loss         | 5.295144e+17  |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 5.174091e-07   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 204            |
    | n_updates          | 721            |
    | policy_entropy     | 0.6408951      |
    | policy_loss        | -6.8675727e-06 |
    | serial_timesteps   | 92288          |
    | time_elapsed       | 440            |
    | total_timesteps    | 92288          |
    | value_loss         | 3.7884498e+17  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 6.47512e-07    |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 195            |
    | n_updates          | 722            |
    | policy_entropy     | 0.6407025      |
    | policy_loss        | 9.5452764e-05  |
    | serial_timesteps   | 92416          |
    | time_elapsed       | 440            |
    | total_timesteps    | 92416          |
    | value_loss         | 1.21018916e+17 |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 9.685414e-07  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 190           |
    | n_updates          | 723           |
    | policy_entropy     | 0.6399612     |
    | policy_loss        | -2.943934e-05 |
    | serial_timesteps   | 92544         |
    | time_elapsed       | 441           |
    | total_timesteps    | 92544         |
    | value_loss         | 1.0457136e+19 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 2.2367968e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 196           |
    | n_updates          | 724           |
    | policy_entropy     | 0.6344478     |
    | policy_loss        | 1.0285061e-05 |
    | serial_timesteps   | 92672         |
    | time_elapsed       | 442           |
    | total_timesteps    | 92672         |
    | value_loss         | 1.1878104e+19 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 4.874552e-08  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 197           |
    | n_updates          | 725           |
    | policy_entropy     | 0.6376834     |
    | policy_loss        | 3.345823e-05  |
    | serial_timesteps   | 92800         |
    | time_elapsed       | 442           |
    | total_timesteps    | 92800         |
    | value_loss         | 2.2377335e+19 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.4530718e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 185           |
    | n_updates          | 726           |
    | policy_entropy     | 0.63700277    |
    | policy_loss        | 3.2763928e-06 |
    | serial_timesteps   | 92928         |
    | time_elapsed       | 443           |
    | total_timesteps    | 92928         |
    | value_loss         | 1.939522e+19  |
    --------------------------------------
    -------------------------------------
    | approxkl           | 1.787239e-09 |
    | clipfrac           | 0.0          |
    | explained_variance | 0            |
    | fps                | 195          |
    | n_updates          | 727          |
    | policy_entropy     | 0.6377337    |
    | policy_loss        | 5.397247e-06 |
    | serial_timesteps   | 93056        |
    | time_elapsed       | 444          |
    | total_timesteps    | 93056        |
    | value_loss         | 9.258597e+18 |
    -------------------------------------
    ---------------------------------------
    | approxkl           | 2.2523036e-08  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 196            |
    | n_updates          | 728            |
    | policy_entropy     | 0.6393402      |
    | policy_loss        | -2.8021168e-06 |
    | serial_timesteps   | 93184          |
    | time_elapsed       | 444            |
    | total_timesteps    | 93184          |
    | value_loss         | 1.6555426e+18  |
    ---------------------------------------
    ------------------------------------------
    | approxkl           | 1.19058704e-07    |
    | clipfrac           | 0.0               |
    | explained_variance | 5.96e-08          |
    | fps                | 241               |
    | n_updates          | 729               |
    | policy_entropy     | 0.63785905        |
    | policy_loss        | 1.074397e-05      |
    | serial_timesteps   | 93312             |
    | time_elapsed       | 445               |
    | total_timesteps    | 93312             |
    | value_loss         | 254613180000000.0 |
    ------------------------------------------
    ------------------------------------------
    | approxkl           | 6.3956605e-08     |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 227               |
    | n_updates          | 730               |
    | policy_entropy     | 0.6384461         |
    | policy_loss        | 8.668983e-06      |
    | serial_timesteps   | 93440             |
    | time_elapsed       | 445               |
    | total_timesteps    | 93440             |
    | value_loss         | 801837500000000.0 |
    ------------------------------------------
    ------------------------------------------
    | approxkl           | 1.3140548e-08     |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 245               |
    | n_updates          | 731               |
    | policy_entropy     | 0.63702875        |
    | policy_loss        | 1.9807136e-05     |
    | serial_timesteps   | 93568             |
    | time_elapsed       | 446               |
    | total_timesteps    | 93568             |
    | value_loss         | 729776400000000.0 |
    ------------------------------------------
    ---------------------------------------
    | approxkl           | 7.408333e-09   |
    | clipfrac           | 0.0            |
    | explained_variance | -2.38e-07      |
    | fps                | 238            |
    | n_updates          | 732            |
    | policy_entropy     | 0.6367029      |
    | policy_loss        | -2.7610222e-06 |
    | serial_timesteps   | 93696          |
    | time_elapsed       | 446            |
    | total_timesteps    | 93696          |
    | value_loss         | 1.6301572e+16  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 3.3228111e-09 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 248           |
    | n_updates          | 733           |
    | policy_entropy     | 0.6365756     |
    | policy_loss        | 4.521804e-06  |
    | serial_timesteps   | 93824         |
    | time_elapsed       | 447           |
    | total_timesteps    | 93824         |
    | value_loss         | 1.419954e+17  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 2.063707e-09  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 237           |
    | n_updates          | 734           |
    | policy_entropy     | 0.6364474     |
    | policy_loss        | -7.06641e-07  |
    | serial_timesteps   | 93952         |
    | time_elapsed       | 448           |
    | total_timesteps    | 93952         |
    | value_loss         | 6.6536374e+18 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 3.8846095e-09  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 246            |
    | n_updates          | 735            |
    | policy_entropy     | 0.63614297     |
    | policy_loss        | -5.5371784e-06 |
    | serial_timesteps   | 94080          |
    | time_elapsed       | 448            |
    | total_timesteps    | 94080          |
    | value_loss         | 2.8929086e+18  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 8.718646e-09   |
    | clipfrac           | 0.0            |
    | explained_variance | 5.96e-08       |
    | fps                | 217            |
    | n_updates          | 736            |
    | policy_entropy     | 0.6375548      |
    | policy_loss        | 4.473375e-06   |
    | serial_timesteps   | 94208          |
    | time_elapsed       | 449            |
    | total_timesteps    | 94208          |
    | value_loss         | 1.38076395e+17 |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 5.8480296e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 190           |
    | n_updates          | 737           |
    | policy_entropy     | 0.6386032     |
    | policy_loss        | 7.4331183e-06 |
    | serial_timesteps   | 94336         |
    | time_elapsed       | 449           |
    | total_timesteps    | 94336         |
    | value_loss         | 2.7654336e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 4.985137e-07  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 184           |
    | n_updates          | 738           |
    | policy_entropy     | 0.64024335    |
    | policy_loss        | 4.7314446e-05 |
    | serial_timesteps   | 94464         |
    | time_elapsed       | 450           |
    | total_timesteps    | 94464         |
    | value_loss         | 1.2622614e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 4.5248956e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 204           |
    | n_updates          | 739           |
    | policy_entropy     | 0.6374027     |
    | policy_loss        | 7.8208395e-06 |
    | serial_timesteps   | 94592         |
    | time_elapsed       | 451           |
    | total_timesteps    | 94592         |
    | value_loss         | 4.4215372e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 4.0182084e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 231           |
    | n_updates          | 740           |
    | policy_entropy     | 0.6399897     |
    | policy_loss        | 5.168561e-05  |
    | serial_timesteps   | 94720         |
    | time_elapsed       | 451           |
    | total_timesteps    | 94720         |
    | value_loss         | 2.1937817e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.3445879e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | -1.19e-07     |
    | fps                | 239           |
    | n_updates          | 741           |
    | policy_entropy     | 0.6387384     |
    | policy_loss        | -9.494368e-06 |
    | serial_timesteps   | 94848         |
    | time_elapsed       | 452           |
    | total_timesteps    | 94848         |
    | value_loss         | 6.19722e+17   |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.897492e-08   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 245            |
    | n_updates          | 742            |
    | policy_entropy     | 0.6411624      |
    | policy_loss        | -1.2707198e-05 |
    | serial_timesteps   | 94976          |
    | time_elapsed       | 452            |
    | total_timesteps    | 94976          |
    | value_loss         | 2.3563725e+17  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 2.8154005e-08  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 214            |
    | n_updates          | 743            |
    | policy_entropy     | 0.63824666     |
    | policy_loss        | -4.1695777e-05 |
    | serial_timesteps   | 95104          |
    | time_elapsed       | 453            |
    | total_timesteps    | 95104          |
    | value_loss         | 4.90722e+18    |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 7.168091e-09  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 194           |
    | n_updates          | 744           |
    | policy_entropy     | 0.63656294    |
    | policy_loss        | 5.782582e-06  |
    | serial_timesteps   | 95232         |
    | time_elapsed       | 453           |
    | total_timesteps    | 95232         |
    | value_loss         | 9.1867814e+18 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 3.514058e-09   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 197            |
    | n_updates          | 745            |
    | policy_entropy     | 0.640451       |
    | policy_loss        | -2.0122388e-06 |
    | serial_timesteps   | 95360          |
    | time_elapsed       | 454            |
    | total_timesteps    | 95360          |
    | value_loss         | 9.964986e+18   |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 4.640694e-07   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 189            |
    | n_updates          | 746            |
    | policy_entropy     | 0.63797855     |
    | policy_loss        | -9.3632436e-05 |
    | serial_timesteps   | 95488          |
    | time_elapsed       | 455            |
    | total_timesteps    | 95488          |
    | value_loss         | 1.7813839e+19  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 9.348567e-07  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 193           |
    | n_updates          | 747           |
    | policy_entropy     | 0.6421439     |
    | policy_loss        | 8.3920546e-05 |
    | serial_timesteps   | 95616         |
    | time_elapsed       | 455           |
    | total_timesteps    | 95616         |
    | value_loss         | 5.283791e+18  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.4559473e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 195           |
    | n_updates          | 748           |
    | policy_entropy     | 0.6420533     |
    | policy_loss        | 4.367996e-05  |
    | serial_timesteps   | 95744         |
    | time_elapsed       | 456           |
    | total_timesteps    | 95744         |
    | value_loss         | 1.1045228e+17 |
    --------------------------------------
    ------------------------------------------
    | approxkl           | 6.859268e-07      |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 193               |
    | n_updates          | 749               |
    | policy_entropy     | 0.6456748         |
    | policy_loss        | -1.2481352e-05    |
    | serial_timesteps   | 95872             |
    | time_elapsed       | 457               |
    | total_timesteps    | 95872             |
    | value_loss         | 335348970000000.0 |
    ------------------------------------------
    -------------------------------------------
    | approxkl           | 4.1064987e-07      |
    | clipfrac           | 0.0                |
    | explained_variance | -1.19e-07          |
    | fps                | 195                |
    | n_updates          | 750                |
    | policy_entropy     | 0.6437788          |
    | policy_loss        | -3.5868376e-05     |
    | serial_timesteps   | 96000              |
    | time_elapsed       | 457                |
    | total_timesteps    | 96000              |
    | value_loss         | 1192897900000000.0 |
    -------------------------------------------
    -------------------------------------------
    | approxkl           | 1.7325385e-07      |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 238                |
    | n_updates          | 751                |
    | policy_entropy     | 0.645166           |
    | policy_loss        | -1.6700942e-06     |
    | serial_timesteps   | 96128              |
    | time_elapsed       | 458                |
    | total_timesteps    | 96128              |
    | value_loss         | 3045458500000000.0 |
    -------------------------------------------
    --------------------------------------
    | approxkl           | 3.5011047e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | -1.19e-07     |
    | fps                | 234           |
    | n_updates          | 752           |
    | policy_entropy     | 0.64563197    |
    | policy_loss        | -2.569682e-05 |
    | serial_timesteps   | 96256         |
    | time_elapsed       | 459           |
    | total_timesteps    | 96256         |
    | value_loss         | 3.751571e+16  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.4863738e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 245           |
    | n_updates          | 753           |
    | policy_entropy     | 0.6423799     |
    | policy_loss        | 3.2456592e-06 |
    | serial_timesteps   | 96384         |
    | time_elapsed       | 459           |
    | total_timesteps    | 96384         |
    | value_loss         | 3.3334014e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 2.4906785e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 227           |
    | n_updates          | 754           |
    | policy_entropy     | 0.6415207     |
    | policy_loss        | 2.944353e-05  |
    | serial_timesteps   | 96512         |
    | time_elapsed       | 460           |
    | total_timesteps    | 96512         |
    | value_loss         | 3.841644e+18  |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 8.665289e-07   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 242            |
    | n_updates          | 755            |
    | policy_entropy     | 0.6405444      |
    | policy_loss        | -3.5521458e-05 |
    | serial_timesteps   | 96640          |
    | time_elapsed       | 460            |
    | total_timesteps    | 96640          |
    | value_loss         | 5.117231e+17   |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 2.4961679e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 227           |
    | n_updates          | 756           |
    | policy_entropy     | 0.64116377    |
    | policy_loss        | 1.3406854e-05 |
    | serial_timesteps   | 96768         |
    | time_elapsed       | 461           |
    | total_timesteps    | 96768         |
    | value_loss         | 1.0477559e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 4.7356633e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 1.19e-07      |
    | fps                | 184           |
    | n_updates          | 757           |
    | policy_entropy     | 0.6405756     |
    | policy_loss        | -6.605277e-05 |
    | serial_timesteps   | 96896         |
    | time_elapsed       | 461           |
    | total_timesteps    | 96896         |
    | value_loss         | 7.478993e+16  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.9158861e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 193           |
    | n_updates          | 758           |
    | policy_entropy     | 0.6424049     |
    | policy_loss        | 3.690133e-05  |
    | serial_timesteps   | 97024         |
    | time_elapsed       | 462           |
    | total_timesteps    | 97024         |
    | value_loss         | 1.8573045e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.195274e-07   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 193            |
    | n_updates          | 759            |
    | policy_entropy     | 0.6406941      |
    | policy_loss        | -3.7700636e-05 |
    | serial_timesteps   | 97152          |
    | time_elapsed       | 463            |
    | total_timesteps    | 97152          |
    | value_loss         | 3.8861744e+17  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 6.2836057e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 200           |
    | n_updates          | 760           |
    | policy_entropy     | 0.64263386    |
    | policy_loss        | 4.5719557e-05 |
    | serial_timesteps   | 97280         |
    | time_elapsed       | 463           |
    | total_timesteps    | 97280         |
    | value_loss         | 2.9360706e+17 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 1.0501028e-06  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 194            |
    | n_updates          | 761            |
    | policy_entropy     | 0.64151114     |
    | policy_loss        | -2.8953888e-05 |
    | serial_timesteps   | 97408          |
    | time_elapsed       | 464            |
    | total_timesteps    | 97408          |
    | value_loss         | 1.6899442e+17  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 1.6577874e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 191           |
    | n_updates          | 762           |
    | policy_entropy     | 0.6469618     |
    | policy_loss        | 0.00015960285 |
    | serial_timesteps   | 97536         |
    | time_elapsed       | 465           |
    | total_timesteps    | 97536         |
    | value_loss         | 4.0767864e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 6.0944336e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 204           |
    | n_updates          | 763           |
    | policy_entropy     | 0.6428599     |
    | policy_loss        | 5.4864213e-06 |
    | serial_timesteps   | 97664         |
    | time_elapsed       | 465           |
    | total_timesteps    | 97664         |
    | value_loss         | 2.623996e+19  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 3.0080926e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 196           |
    | n_updates          | 764           |
    | policy_entropy     | 0.6436678     |
    | policy_loss        | 1.1558877e-05 |
    | serial_timesteps   | 97792         |
    | time_elapsed       | 466           |
    | total_timesteps    | 97792         |
    | value_loss         | 3.2663366e+19 |
    --------------------------------------
    ---------------------------------------
    | approxkl           | 7.3214716e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 189            |
    | n_updates          | 765            |
    | policy_entropy     | 0.64563924     |
    | policy_loss        | -0.00011108979 |
    | serial_timesteps   | 97920          |
    | time_elapsed       | 467            |
    | total_timesteps    | 97920          |
    | value_loss         | 1.6651304e+19  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 3.4256772e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 195           |
    | n_updates          | 766           |
    | policy_entropy     | 0.64278495    |
    | policy_loss        | 6.5154745e-05 |
    | serial_timesteps   | 98048         |
    | time_elapsed       | 467           |
    | total_timesteps    | 98048         |
    | value_loss         | 1.8279702e+19 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.2356486e-08 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 195           |
    | n_updates          | 767           |
    | policy_entropy     | 0.64375806    |
    | policy_loss        | 1.7120037e-06 |
    | serial_timesteps   | 98176         |
    | time_elapsed       | 468           |
    | total_timesteps    | 98176         |
    | value_loss         | 6.481472e+18  |
    --------------------------------------
    ------------------------------------------
    | approxkl           | 5.2285025e-09     |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 192               |
    | n_updates          | 768               |
    | policy_entropy     | 0.6440835         |
    | policy_loss        | -5.358015e-06     |
    | serial_timesteps   | 98304             |
    | time_elapsed       | 469               |
    | total_timesteps    | 98304             |
    | value_loss         | 432440460000000.0 |
    ------------------------------------------
    ------------------------------------------
    | approxkl           | 2.4282548e-07     |
    | clipfrac           | 0.0               |
    | explained_variance | 0                 |
    | fps                | 198               |
    | n_updates          | 769               |
    | policy_entropy     | 0.6479428         |
    | policy_loss        | 9.322539e-07      |
    | serial_timesteps   | 98432             |
    | time_elapsed       | 469               |
    | total_timesteps    | 98432             |
    | value_loss         | 648808770000000.0 |
    ------------------------------------------
    -------------------------------------------
    | approxkl           | 6.6601837e-07      |
    | clipfrac           | 0.0                |
    | explained_variance | 5.96e-08           |
    | fps                | 201                |
    | n_updates          | 770                |
    | policy_entropy     | 0.6426827          |
    | policy_loss        | 0.00015175203      |
    | serial_timesteps   | 98560              |
    | time_elapsed       | 470                |
    | total_timesteps    | 98560              |
    | value_loss         | 1280803800000000.0 |
    -------------------------------------------
    -------------------------------------------
    | approxkl           | 1.240378e-07       |
    | clipfrac           | 0.0                |
    | explained_variance | 0                  |
    | fps                | 239                |
    | n_updates          | 771                |
    | policy_entropy     | 0.6432267          |
    | policy_loss        | -5.766796e-05      |
    | serial_timesteps   | 98688              |
    | time_elapsed       | 471                |
    | total_timesteps    | 98688              |
    | value_loss         | 5571088000000000.0 |
    -------------------------------------------
    ---------------------------------------
    | approxkl           | 2.6512157e-07  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 234            |
    | n_updates          | 772            |
    | policy_entropy     | 0.64292175     |
    | policy_loss        | -2.4563284e-05 |
    | serial_timesteps   | 98816          |
    | time_elapsed       | 471            |
    | total_timesteps    | 98816          |
    | value_loss         | 2.5796529e+17  |
    ---------------------------------------
    --------------------------------------
    | approxkl           | 6.4465564e-07 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 234           |
    | n_updates          | 773           |
    | policy_entropy     | 0.6439141     |
    | policy_loss        | 6.153318e-05  |
    | serial_timesteps   | 98944         |
    | time_elapsed       | 472           |
    | total_timesteps    | 98944         |
    | value_loss         | 6.070731e+17  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.033166e-06  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 215           |
    | n_updates          | 774           |
    | policy_entropy     | 0.6421665     |
    | policy_loss        | 7.42299e-06   |
    | serial_timesteps   | 99072         |
    | time_elapsed       | 472           |
    | total_timesteps    | 99072         |
    | value_loss         | 1.5498437e+19 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 1.1521545e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 198           |
    | n_updates          | 775           |
    | policy_entropy     | 0.6442492     |
    | policy_loss        | -6.94911e-05  |
    | serial_timesteps   | 99200         |
    | time_elapsed       | 473           |
    | total_timesteps    | 99200         |
    | value_loss         | 1.6760237e+17 |
    --------------------------------------
    --------------------------------------
    | approxkl           | 2.3634225e-06 |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 246           |
    | n_updates          | 776           |
    | policy_entropy     | 0.6483019     |
    | policy_loss        | -0.0001809732 |
    | serial_timesteps   | 99328         |
    | time_elapsed       | 473           |
    | total_timesteps    | 99328         |
    | value_loss         | 2.578709e+17  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 7.700811e-07  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 239           |
    | n_updates          | 777           |
    | policy_entropy     | 0.6476505     |
    | policy_loss        | -2.301368e-05 |
    | serial_timesteps   | 99456         |
    | time_elapsed       | 474           |
    | total_timesteps    | 99456         |
    | value_loss         | 7.954105e+16  |
    --------------------------------------
    --------------------------------------
    | approxkl           | 7.603616e-07  |
    | clipfrac           | 0.0           |
    | explained_variance | 0             |
    | fps                | 241           |
    | n_updates          | 778           |
    | policy_entropy     | 0.64764786    |
    | policy_loss        | 4.8784073e-05 |
    | serial_timesteps   | 99584         |
    | time_elapsed       | 475           |
    | total_timesteps    | 99584         |
    | value_loss         | 2.7366236e+17 |
    --------------------------------------
    ----------------------------------------
    | approxkl           | 1.5854623e-06   |
    | clipfrac           | 0.0             |
    | explained_variance | 0               |
    | fps                | 237             |
    | n_updates          | 779             |
    | policy_entropy     | 0.64791036      |
    | policy_loss        | -0.000100412406 |
    | serial_timesteps   | 99712           |
    | time_elapsed       | 475             |
    | total_timesteps    | 99712           |
    | value_loss         | 3.1688138e+17   |
    ----------------------------------------
    ---------------------------------------
    | approxkl           | 3.7905736e-06  |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 244            |
    | n_updates          | 780            |
    | policy_entropy     | 0.65035284     |
    | policy_loss        | -0.00015571108 |
    | serial_timesteps   | 99840          |
    | time_elapsed       | 476            |
    | total_timesteps    | 99840          |
    | value_loss         | 1.2307623e+18  |
    ---------------------------------------
    ---------------------------------------
    | approxkl           | 6.737061e-06   |
    | clipfrac           | 0.0            |
    | explained_variance | 0              |
    | fps                | 240            |
    | n_updates          | 781            |
    | policy_entropy     | 0.6532042      |
    | policy_loss        | -4.2208238e-05 |
    | serial_timesteps   | 99968          |
    | time_elapsed       | 476            |
    | total_timesteps    | 99968          |
    | value_loss         | 4.2795494e+17  |
    ---------------------------------------
    




    <stable_baselines.ppo2.ppo2.PPO2 at 0x7f33d8bd5210>



## Save model



```python
model.save("ppo2_forex-v0_lstm")
```

## Load model


```python
model = PPO2.load("ppo2_forex-v0_lstm")
```

    WARNING:tensorflow:Entity <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f33c88af750>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f33c88af750>>: AttributeError: module 'gast' has no attribute 'Index'
    

    Loading a model without an environment, this model cannot be trained until it has a valid environment.
    WARNING: Entity <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f33c88af750>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f33c88af750>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING:tensorflow:Entity <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f33c7176690>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f33c7176690>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING: Entity <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f33c7176690>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method Flatten.call of <tensorflow.python.layers.core.Flatten object at 0x7f33c7176690>>: AttributeError: module 'gast' has no attribute 'Index'
    

## Test  trade


```python
import numpy as np

# env = DummyVecEnv([env_maker for _ in range(10)])
# env = env_maker()
env = env_marker2()
observation = env.reset()

while True:
    observation = observation[np.newaxis, ...]
    #observation = np.tile(observation, (10, 1, 1))

    # ----------------------------
    # observation
    #
    # print(observation)
    # print(observation.shape)

    # action = env.action_space.sample()
    action, _states = model.predict(observation)
    # print(action.shape)
    observation, reward, done, info = env.step(action)

    # print(done)
    # env.render()
    if done:
        print("info:", info)
        break
```

    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    False
    True
    info: {'total_reward': 34887850000.0, 'total_profit': -2.2556078418342185e-09, 'position': 1}
    

## Analysis Using quantstats

ポートフォリオのプロファイリングを行い，詳細な分析とリスクメトリクスを算出します．


```python
print(env)
print(len(env.history['total_profit']))
print(len(df_dataset.index))
print(len(df_dataset.index[idx1:idx2]))
```

    <MyBTCEnv instance>
    2517
    2618
    2518
    


```python
qs.extend_pandas()

net_worth = pd.Series(env.history['total_profit'], index=df_dataset.index[idx1+1:idx2])
returns = net_worth.pct_change().iloc[1:]

qs.reports.full(returns)
qs.reports.html(returns, output='a2c_quantstats.html')
```

    [Performance Metrics]
    
    

    WARNING:matplotlib.font_manager:findfont: Font family ['Arial'] not found. Falling back to DejaVu Sans.
    

                               Strategy
    -------------------------  ----------
    Start Period               2015-10-06
    End Period                 2022-08-26
    Risk-Free Rate             0.0%
    Time in Market             25.0%
    
    Cumulative Return          -100.0%
    CAGR﹪                     -94.43%
    
    Sharpe                     -0.07
    Prob. Sharpe Ratio         41.53%
    Smart Sharpe               -0.07
    Sortino                    -0.11
    Smart Sortino              -0.11
    Sortino/√2                 -0.07
    Smart Sortino/√2           -0.07
    Omega                      0.96
    
    Max Drawdown               -100.0%
    Longest DD Days            2514
    Volatility (ann.)          64.95%
    Calmar                     -0.94
    Skew                       2.55
    Kurtosis                   330.46
    
    Expected Daily %           -
    Expected Monthly %         -
    Expected Yearly %          -
    Kelly Criterion            -1.53%
    Risk of Ruin               0.0%
    Daily Value-at-Risk        -6.75%
    Expected Shortfall (cVaR)  -6.75%
    
    Max Consecutive Wins       1
    Max Consecutive Losses     1
    Gain/Pain Ratio            -0.04
    Gain/Pain (1M)             -0.07
    
    Payoff Ratio               1.38
    Profit Factor              0.96
    Common Sense Ratio         0.79
    CPC Index                  0.55
    Tail Ratio                 0.82
    Outlier Win Ratio          19.11
    Outlier Loss Ratio         2.67
    
    MTD                        7.08%
    3M                         3.97%
    6M                         14.57%
    YTD                        66.02%
    1Y                         85.72%
    3Y (ann.)                  -7.23%
    5Y (ann.)                  -3.61%
    10Y (ann.)                 -94.43%
    All-time (ann.)            -94.43%
    
    Best Day                   103.97%
    Worst Day                  -100.0%
    Best Month                 73.21%
    Worst Month                -100.0%
    Best Year                  166.74%
    Worst Year                 -100.0%
    
    Avg. Drawdown              -100.0%
    Avg. Drawdown Days         2514
    Recovery Factor            -1.0
    Ulcer Index                0.93
    Serenity Index             -0.03
    
    Avg. Up Month              16.8%
    Avg. Down Month            -12.29%
    Win Days %                 41.06%
    Win Month %                39.76%
    Win Quarter %              50.0%
    Win Year %                 25.0%
    
    
    
    [5 Worst Drawdowns]
    
        Start       Valley      End           Days    Max Drawdown    99% Max Drawdown
    --  ----------  ----------  ----------  ------  --------------  ------------------
     1  2015-10-08  2019-02-09  2022-08-26    2514         -100.00             -100.00
    
    
    
    [Strategy Visualization]
    via Matplotlib
    


    
![png](output_35_3.png)
    



    
![png](output_35_4.png)
    



    
![png](output_35_5.png)
    



    
![png](output_35_6.png)
    



    
![png](output_35_7.png)
    



    
![png](output_35_8.png)
    



    
![png](output_35_9.png)
    



    
![png](output_35_10.png)
    



    
![png](output_35_11.png)
    



    
![png](output_35_12.png)
    



    
![png](output_35_13.png)
    



    
![png](output_35_14.png)
    


## Plot Results


```python
plt.figure(figsize=(30, 10))
env.render_all()
plt.show()
```


    
![png](output_37_0.png)
    


# Tensorboard


```python
# Load the TensorBoard notebook extension
%load_ext tensorboard
```


```python
%tensorboard --logdir logs/
```



<div id="root"></div>
<script>
  (function() {
    window.TENSORBOARD_ENV = window.TENSORBOARD_ENV || {};
    window.TENSORBOARD_ENV["IN_COLAB"] = true;
    document.querySelector("base").href = "https://localhost:6006";
    function fixUpTensorboard(root) {
      const tftb = root.querySelector("tf-tensorboard");
      // Disable the fragment manipulation behavior in Colab. Not
      // only is the behavior not useful (as the iframe's location
      // is not visible to the user), it causes TensorBoard's usage
      // of `window.replace` to navigate away from the page and to
      // the `localhost:<port>` URL specified by the base URI, which
      // in turn causes the frame to (likely) crash.
      tftb.removeAttribute("use-hash");
    }
    function executeAllScripts(root) {
      // When `script` elements are inserted into the DOM by
      // assigning to an element's `innerHTML`, the scripts are not
      // executed. Thus, we manually re-insert these scripts so that
      // TensorBoard can initialize itself.
      for (const script of root.querySelectorAll("script")) {
        const newScript = document.createElement("script");
        newScript.type = script.type;
        newScript.textContent = script.textContent;
        root.appendChild(newScript);
        script.remove();
      }
    }
    function setHeight(root, height) {
      // We set the height dynamically after the TensorBoard UI has
      // been initialized. This avoids an intermediate state in
      // which the container plus the UI become taller than the
      // final width and cause the Colab output frame to be
      // permanently resized, eventually leading to an empty
      // vertical gap below the TensorBoard UI. It's not clear
      // exactly what causes this problematic intermediate state,
      // but setting the height late seems to fix it.
      root.style.height = `${height}px`;
    }
    const root = document.getElementById("root");
    fetch(".")
      .then((x) => x.text())
      .then((html) => void (root.innerHTML = html))
      .then(() => fixUpTensorboard(root))
      .then(() => executeAllScripts(root))
      .then(() => setHeight(root, 800));
  })();
</script>


